# FT HT0-0 → Home Edge · 全场独立手机版 / 手表版 v1.0

## 目标

基于用户上传的 `HT_SelectorGuard_v2_6_Notification_DirectMatch_Fix_OneUpload.zip` 创建**独立**手机及 Wear OS App。新包名两端均为 `com.htlive.ft.ht00homeedge.watch8`，与旧包名 `com.htlive.monitor.scorepathguard.watch8` 不同；分别安装在手机和手表，与旧版本共存。保留原有暗色界面布局、候选列表、近7场半/全场战绩、直接加入预警、跳转对应场次、个人主单/保险单编辑、原有通知渠道与声音、图片识别、圆形手表页面、独立本地候选缓存及全场复盘。**不再出现半场筛选入口**，但会读取半场数据，也会在上半场15/30/40分钟持续观察本场全场合约。

## 两阶段筛选

第一阶段先检查比赛双方最近20场已完成常规联赛中包含真实半场和全场比分的数据（对应主/客最多10场）：

- 主场队的历史上半场0-0发生比例、客场队的上半场0-0发生比例。
- 双方半场进球/失球构成的简单泊松估计与场地经验比例收缩混合。
- 从 API-FOOTBALL `/odds/bets` 识别半场正确比分市场，再从真实 Bet365 半场正确比分读取 `0-0` 赔率；若有半场0.5/1.5小球用于交叉审计。
- 半场0-0估计小于32%直接PASS；32–40%较弱需要特别警示。市场缺失/赔率冲突不能升级高评级。**32%、40%仅为待回测的研究门槛，不能保证预测准确。**

第二阶段只有在符合第一阶段的前提下，研究历史记录中“HT0-0 → 第二阶段进球 → 最终比分”的结构：

- 主队主场和客队客场各自过去HT0-0的全场比分/下半场进失球分布。
- 结合双方一般下半场进球率，将小样本HT0-0条件结果向大样本回缩。
- 估计“已在中场0-0”时最终1-0/0-0/2-0/1-1/2-1/0-1等比分的**条件概率**。条件概率不能直接拿来当赛前全场命中率。主队明显优势时，候选1-0主单，附最多两张备用。没有合理结构时PASS。
- 在完整真实Bet365全场正确比分市场/全场胜平负/3.5大小球中交叉核验。**赔率不限4.0和0-0下限，但真实报价不足时只能C观察**。
- 重点排除：主队在下半场没有优势、客队反击过强、下半场爆发多球、最终仍0-0概率过高、赔率与模型冲突、样本不足、赛前阵容不确定。

AI API：设置 OpenAI Key 后，按半场0-0证据、下半场进球结构、完整报价与资料缺口进行前六场A/B的**保守审核**（AI不能把C/PASS升级）；亦可手动点单场“AI双阶段复核”。无AI Key可独立数据扫描，但显示“AI未复核”。API-FOOTBALL与OpenAI Key不会写入ZIP或CSV。单场模型预测和AI评级均未经完整回测校准。

## 预警与手表

- 原 `MonitorService / ReminderReceiver / WearMatchSync / WearAlertListener / WearAlertActivity` 的消息/通知逻辑保持不变；独立App的包名使本地文件、通知、手机↔手表数据层独立。
- 首次勾选赛前比赛后仍在开赛第3分钟进行真实赛况确认，15/30/40及60/75/85节点按原逻辑提醒。保持原始通知被点击时进入当前指定比赛，而非停留在总览的修复。
- C/PASS仍允许勾选**人工观察**，不自动设置下注比分。
- 实时xG/危险进攻/API缺口不会编造成可靠数据。上半场0-0的筛选只是赛前假设；到了中场之后必须重新根据实际比分、数据和赔率决定是否继续观察。

## GitHub构建

本环境未安装Gradle/Android SDK，无法在本地直接编出新的APK。项目附带 `.github/workflows/build-apk.yml`；在带Android SDK 35的GitHub Actions中测试并执行：

```bash
gradle :app:assembleDebug :wear:assembleDebug --no-daemon --stacktrace --console=plain
```

输出两个互不覆盖旧版的可安装APK：

- `app/build/outputs/apk/debug/app-debug.apk`
- `wear/build/outputs/apk/debug/wear-debug.apk`

GitHub Actions Artifacts 显示为 `FT-HT00-HomeEdge-v1.0-PHONE-APK` / `FT-HT00-HomeEdge-v1.0-WATCH-APK`。

**重要：GitHub不会自动解压仓库中上传的ZIP。**新仓库必须先有 `.github/workflows/build-apk.yml`，然后可将 `FT_Halftime00_HomeEdge_v1_0_OneUpload.zip` 上传到仓库根目录，Actions将它解压用于构建；或将本包解压后把源码目录逐一上传到仓库。若上传 ZIP 同时还没有 workflow，需先单独创建 workflow 文件。

签名：继承 v2.6 测试用自签名证书，供本机开发；不适合生产发布。若准备发布，应更换签名，验证旧版和独立新版在同一设备上并行收发消息，检查后台系统限时/电池优化和真实API报价。

## 单元测试

`node tests/ft_ht00_engine_v1.test.js`，所有当前适用的JS测试可运行 `for f in tests/*.test.js; do node "$f"; done`。旧HT/FT双模式UI测试和旧包名版本号测试保存在 `tests/legacy_archived`（新版的界面/包名预期不同），原通知与Wear数据层测试仍在主测试套件。
