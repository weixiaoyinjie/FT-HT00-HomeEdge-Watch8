package com.htlive.watch44;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.view.View;

/** Round-face-aware, single-screen alert summary: widths follow the circle chord. */
final class WatchGlanceView extends View {
    private static final int AQUA=0xff66e7da;
    private static final int MUTED=0xffb0c3ce;
    private final WearBrief brief;
    private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG|Paint.SUBPIXEL_TEXT_FLAG);
    private float centerX;

    WatchGlanceView(Context context,WearBrief summary){
        super(context);brief=summary;
        setBackgroundColor(Color.BLACK);
        setContentDescription("手表赛况通知。"+brief.nativeExpanded()+"。向上滑动或点按查看完整分析");
    }
    @Override protected void onDraw(Canvas c){
        super.onDraw(c);
        float w=getWidth(),h=getHeight(),d=Math.min(w,h);
        if(d<=0)return;
        c.save(); c.translate((w-d)/2,(h-d)/2);
        centerX=d/2f;
        paint.setStyle(Paint.Style.FILL);paint.setColor(0xff07131d);
        c.drawCircle(d/2,d/2,d*.478f,paint);
        paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(d*.004f);
        paint.setColor(0xff294450);c.drawCircle(d/2,d/2,d*.475f,paint);
        paint.setStyle(Paint.Style.FILL);
        drawFit(c,brief.header,d*.151f,d*.051f,AQUA,true,chord(d,.151f));
        drawFit(c,brief.teams,d*.241f,d*.060f,Color.WHITE,true,chord(d,.241f));
        drawFit(c,brief.score,d*.366f,d*.122f,Color.WHITE,true,chord(d,.366f));
        paint.setColor(0xff233944);
        c.drawRoundRect(new RectF(d*.25f,d*.416f,d*.75f,d*.420f),d*.01f,d*.01f,paint);
        drawFit(c,"我的下单比分",d*.465f,d*.047f,MUTED,false,chord(d,.465f));
        drawPicks(c,d);
        int riskColor=("BROKEN".equals(brief.level)||"HIGH".equals(brief.level))?0xffffa3a0:
                      ("WATCH".equals(brief.level)||"PARTIAL".equals(brief.level))?0xffffc074:0xffffd494;
        drawFit(c,brief.risk,d*.695f,d*.052f,riskColor,true,chord(d,.695f));
        drawFit(c,brief.action,d*.774f,d*.051f,Color.WHITE,true,chord(d,.774f));
        drawFit(c,brief.dataLabel+" · "+brief.ageLabel,d*.842f,d*.037f,MUTED,false,chord(d,.842f));
        drawFit(c,"↑ 上滑看完整信息",d*.892f,d*.034f,AQUA,false,chord(d,.892f));
        c.restore();
    }
    private float chord(float d,float y){
        // Round display: horizontal safe width shrinks towards the poles.
        float radius=.468f*d,offset=(y-.5f)*d;
        float allowed=2f*(float)Math.sqrt(Math.max(0,radius*radius-offset*offset));
        return Math.max(d*.25f,allowed-d*.040f);
    }
    private void font(float px,int color,boolean bold){
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(color);
        paint.setTypeface(bold?Typeface.create("sans-serif",Typeface.BOLD):
            Typeface.create("sans-serif",Typeface.NORMAL));
        paint.setTextSize(px);
        paint.setTextAlign(Paint.Align.CENTER);
    }
    private void drawFit(Canvas c,String raw,float baseline,float size,int color,boolean bold,float width){
        String str=raw==null?"":raw.replace('\n',' ').replace('\r',' ').trim();
        font(size,color,bold);
        if(paint.measureText(str)>width){
            // Scale a little before clipping, but never make tiny unreadable text.
            float scaled=Math.max(size*.81f,size*width/Math.max(width,paint.measureText(str)));
            paint.setTextSize(scaled);
            while(str.length()>1 && paint.measureText(str)>width){
                int last=str.offsetByCodePoints(str.length(),-1);
                str=str.substring(0,last);
            }
            // Never exceed the circular chord after adding an ellipsis.
            if(!str.equals(raw) && str.length()>1){
                while(str.length()>1 && paint.measureText(str+"…")>width){
                    str=str.substring(0,str.offsetByCodePoints(str.length(),-1));
                }
                str+="…";
            }
        }
        c.drawText(str,centerX,baseline,paint);
    }
    private void drawPicks(Canvas c,float d){
        WearBrief.Pick[] arr=brief.picks;
        if(arr.length==0){
            drawFit(c,"主单 / 保险单未同步",d*.563f,d*.052f,0xffffcc80,true,chord(d,.563f));
            return;
        }
        float center=d/2f;
        float cardWidth=(arr.length==3?.273f:arr.length==2?.340f:.45f)*d;
        float gap=d*.013f;
        float total=arr.length*cardWidth+(arr.length-1)*gap;
        float start=center-total/2f;
        for(int i=0;i<arr.length;i++){
            WearBrief.Pick p=arr[i];
            float left=start+i*(cardWidth+gap);
            RectF bounds=new RectF(left,d*.499f,left+cardWidth,d*.620f);
            paint.setColor(0xff172c38);paint.setStyle(Paint.Style.FILL);
            c.drawRoundRect(bounds,d*.019f,d*.019f,paint);
            paint.setColor(p.color);paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(d*.003f);
            c.drawRoundRect(bounds,d*.019f,d*.019f,paint);
            paint.setStyle(Paint.Style.FILL);
            // The two rows share one high-priority tile: pick + its actual state.
            float x=left+cardWidth/2f;
            font(d*.053f,Color.WHITE,true);
            String label=p.label;
            while(label.length()>1 && paint.measureText(label)>cardWidth*.91f){
                label=label.substring(0,label.offsetByCodePoints(label.length(),-1));
            }
            c.drawText(label,x,d*.549f,paint);
            font(d*.040f,p.color,true);
            c.drawText(p.state,x,d*.599f,paint);
        }
    }
}
