package com.htlive.watch44;

import android.content.Context;
import android.content.SharedPreferences;
import android.widget.TextView;
import com.google.android.gms.wearable.Node;
import com.google.android.gms.wearable.Wearable;
import java.nio.charset.StandardCharsets;
import java.util.UUID;

/** Wearable Data Layer calls are isolated from the native startup Activity. */
final class WearConnectionProbe {
    private WearConnectionProbe() {}
    static void ping(Context context, TextView result) {
        String token=UUID.randomUUID().toString();
        SharedPreferences pref=context.getSharedPreferences("watch44_alerts",Context.MODE_PRIVATE);
        pref.edit().putString("pending_ping",token).putLong("phone_pong_at",0L).apply();
        Wearable.getNodeClient(context).getConnectedNodes()
          .addOnSuccessListener(nodes -> {
             if(nodes==null || nodes.isEmpty()) {result.setText("未发现已连接手机");return;}
             result.setText("找到手机 · 等待 App 回应");
             for(Node node:nodes) {
                 Wearable.getMessageClient(context).sendMessage(node.getId(),
                    "/scorepath/ping",token.getBytes(StandardCharsets.UTF_8))
                    .addOnFailureListener(e -> result.setText("发送失败 · 检查手机端"));
             }
          })
          .addOnFailureListener(e -> result.setText("连接检测失败 · 请检查配对"));
    }
}
