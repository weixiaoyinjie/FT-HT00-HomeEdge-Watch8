SelectorGuard v2.6 — 点击监控通知直达对应比赛详情

仓库名称：继续使用 HT-SelectorGuard-v2-5-FT-Watch8，无需重新创建。

仓库根目录新上传：
HT_SelectorGuard_v2_6_Notification_DirectMatch_Fix_OneUpload.zip

原仓库文件 .github/workflows/build-apk.yml ：
用 build-apk-v2-6.yml 的完整内容替换并 Commit changes。

然后 Actions -> Build HT SelectorGuard v2.6 Phone and Watch8 -> Run workflow。
构建产物：HT-v2.6-PHONE-APK (app-debug.apk)、HT-v2.6-WATCH8-APK (wear-debug.apk)。

验证时，请点击用v2.6重新产生的“具体比赛预警”通知；历史通知可能继续保留v2.5打开方式。
单场运行状态通知直达比赛详情，多场状态通知进入实时分析列表。
旧版半场、全场筛选和Watch8通知同步的判断逻辑未修改。
尚未执行Android真机验证；本地缺少SDK，因此不提供未验证的APK。
