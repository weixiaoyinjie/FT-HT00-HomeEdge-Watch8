'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs');
const e=require('../app/src/main/assets/ft_ht00_engine.js');
const t='2026-12-06T13:00:00+00:00';
const fixture={fixture:{id:123,date:t,status:{short:'NS'}},teams:{home:{id:10},away:{id:20}},league:{type:'League',name:'Premier League'}};
function game(team,i,home,ht,ft){let H=home?team:600+i,A=home?600+i:team;return {fixture:{id:100000+team*100+i,date:new Date(Date.parse(t)-(i+1)*86400e3).toISOString(),status:{short:'FT'}},league:{type:'League',name:'Premier League'},teams:{home:{id:H},away:{id:A}},score:{halftime:{home:ht[0],away:ht[1]},fulltime:{home:ft[0],away:ft[1]}}};}
const hs=Array.from({length:20},(_,i)=>game(10,i,true,i%4===0?[1,0]:[0,0],i%4===0?[2,0]:[1,0]));
const as=Array.from({length:20},(_,i)=>game(20,i,false,i%4===0?[1,0]:[0,0],i%4===0?[2,0]:[1,0]));
function odds(opt={}){const half=[{id:101,name:'First Half Correct Score',values:[{value:'0-0',odd:'1.45'}]},
{id:102,name:'First Half Goals Over/Under',values:[{value:'Under 0.5',odd:'1.45'},{value:'Over 0.5',odd:'3'},{value:'Under 1.5',odd:'1.15'}]}];
const full=[{id:201,name:'Correct Score',values:['0-0','1-0','2-0','1-1','2-1','0-1'].map(x=>({value:x,odd:'7.50'}))},
{id:202,name:'Match Winner',values:[{value:'Home',odd:'1.70'},{value:'Draw',odd:'3.50'},{value:'Away',odd:'6.00'}]},
{id:203,name:'Goals Over/Under',values:[{value:'Over 3.5',odd:'4.00'},{value:'Under 3.5',odd:'1.24'}]}];
return [{bookmakers:[{name:opt.wrongBook?'NotBet365':'Bet365',bets:[...(opt.noHalf?[]:half),...(opt.noFull?[]:full)]}]}];}
const marketIds={htExactIds:[101],htOUIds:[102],ftExactIds:[201],ftWinIds:[202]};
const good=e.analyze({fixture,homeHistory:hs,awayHistory:as,oddsRows:odds(),marketIds});
assert(good.fit&&good.fit.pHT00>=.32,good.reason);
assert(good.fit.lh>good.fit.la,good.reason);
assert(['A','B'].includes(good.grade),`expected candidate; got ${good.grade}: ${good.reason}`);
assert.equal(good.combo.main,'1-0');assert.equal(good.combo.scores.length,3);
assert(good.combo.items.every(x=>x.odd===7.5));
assert(good.fit.pJoint10<good.fit.pHT00,'unconditional probability must be smaller than HT00 probability');
const missing=e.analyze({fixture,homeHistory:hs,awayHistory:as,oddsRows:odds({noHalf:true}),marketIds});
assert.equal(missing.grade,'C','Missing HT 0-0 Bet365 quote is not A/B');
const noFull=e.analyze({fixture,homeHistory:hs,awayHistory:as,oddsRows:odds({noFull:true}),marketIds});
assert.equal(noFull.grade,'C','Missing FT correct-score quote is not A/B');
const wrongBook=e.analyze({fixture,homeHistory:hs,awayHistory:as,oddsRows:odds({wrongBook:true}),marketIds});
assert.equal(wrongBook.grade,'C');
const empty=e.analyze({fixture,homeHistory:[],awayHistory:[],oddsRows:odds(),marketIds});assert.equal(empty.grade,'PASS');
const stale=JSON.parse(JSON.stringify(fixture));stale.fixture.status.short='1H';const live=e.analyze({fixture:stale,homeHistory:hs,awayHistory:as,oddsRows:odds(),marketIds});assert.equal(live.grade,'PASS');
const s=fs.readFileSync('app/src/main/assets/selector.html','utf8');
assert(!s.includes('id="periodHT"'),'FT-only app must not expose HT selector');
assert(s.includes('FTHalf00Engine.analyze'));assert(s.includes('ht00Model:'));assert(s.includes('openFTAIAnalysis'));
const a=fs.readFileSync('app/build.gradle','utf8'),w=fs.readFileSync('wear/build.gradle','utf8');
assert(a.includes("applicationId 'com.htlive.ft.ht00homeedge.watch8'"));assert(w.includes("applicationId 'com.htlive.ft.ht00homeedge.watch8'"));
const native=fs.readFileSync('app/src/main/java/com/htlive/monitor/SelectorMonitorSync.java','utf8');
assert(native.includes('entry.optDouble("ht00Model",0)<.32'));assert(native.includes('entry.optDouble("zeroModel",1)>=.43'));
console.log('PASS: two-stage HT00→FT low-score, real Bet365 HT/FT separation, C on missing markets, FT-only independent apps');
