/** Source-level regression test; Android install/run must still be verified on actual Watch8. */
const fs=require('fs');
const assert=require('assert');
const watch=fs.readFileSync('wear/src/main/java/com/htlive/watch44/WearAlertActivity.java','utf8');
const home=fs.readFileSync('wear/src/main/java/com/htlive/watch44/WatchHomeActivity.java','utf8');
const probe=fs.readFileSync('wear/src/main/java/com/htlive/watch44/WearConnectionProbe.java','utf8');
const listener=fs.readFileSync('wear/src/main/java/com/htlive/watch44/WearAlertListener.java','utf8');
const phone=fs.readFileSync('app/src/main/java/com/htlive/monitor/WearPhoneListener.java','utf8');
const mw=fs.readFileSync('wear/src/main/AndroidManifest.xml','utf8');
const mp=fs.readFileSync('app/src/main/AndroidManifest.xml','utf8');
assert(watch.includes('检测手机连接') && watch.includes('测试手表通知'));
assert(watch.includes('开启通知权限') && watch.includes('返回手表首页'));
assert(watch.includes('showHome()') && watch.includes('showDetail('));
assert(listener.includes('postDemo(Context context)'));
assert(watch.includes('"/scorepath/ping"'));
assert(phone.includes('"/scorepath/pong"'));
assert(listener.includes('"/scorepath/pong"'));
assert(listener.includes('putString("alert_"+nid') && listener.includes('if(!canNotify(this)) return'));
assert(mw.includes('android.intent.category.LAUNCHER'));
assert(mw.includes('com.htlive.watch44.WatchHomeActivity'));
assert(mw.includes('android:icon="@drawable/ic_watch_score"'));
assert(home.includes('启动检测 · 首页已打开') && home.includes('测试本地通知'));
assert(home.includes('检查手机连接') || home.includes('检测手机连接'));
assert(home.includes('WearConnectionProbe.ping') && probe.includes('getConnectedNodes()'));
assert(!home.includes('import com.google.android.gms'));
assert(fs.existsSync('wear/src/main/res/drawable/ic_watch_score.xml'));
assert(mp.includes('com.htlive.monitor.WearPhoneListener'));
for(const moduleName of ['wear','app']){
 const gradle=fs.readFileSync(`${moduleName}/build.gradle`,'utf8');
 assert(gradle.includes('signing/watch8-development.jks'));
 assert(Number((gradle.match(/versionCode\s+(\d+)/)||[])[1]) >= (moduleName==='app'?13:12), 'versionCode must not regress');
}
console.log('PASS: safe watch launcher, permission, local notification, 2-way ping/pong, same signing identity');
