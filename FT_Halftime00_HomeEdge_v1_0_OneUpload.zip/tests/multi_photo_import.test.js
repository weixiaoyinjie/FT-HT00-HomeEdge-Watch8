/* Exercise the actual HTML import transaction without WebView or API network. */
const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const source=fs.readFileSync('app/src/main/assets/index.html','utf8');
const parserCtx={};vm.runInNewContext(fs.readFileSync('app/src/main/assets/import_parser.js','utf8'),parserCtx);
const start=source.indexOf('function scanPhoto(p){');
const stop=source.indexOf('async function loadScreenshotFixtures(',start);
const code=source.slice(start,stop);
assert(code.includes('function autoImportScreenshots()'));
const fixtures=Array.from({length:12},(_,i)=>({id:String(1800100+i),home:`Team${i+100}`,away:`Guest${i+100}`,kickoff:'2026-10-16T22:20:00Z',league:'A'}));
const photo=(id,offset,count)=>({id,ocrPending:false,ocrText:Array.from({length:count},(_,i)=>{
 let v=offset+i;return `2026-10-16 19:20 开赛\nTeam${v+100} vs Guest${v+100}\nFixture ID: ${1800100+v}`;
}).join('\n'),ocrEdited:true,importedIds:[],unmatched:[]});
function scenario(photos){
 const ctx={photos,watch:[],HTImportParser:parserCtx.HTImportParser,
  fixtureCandidates:()=>fixtures,store:()=>true,renderPhotos:()=>{},armAutoWatch:()=>{ctx.armCount++},
  armCount:0,applyWatchlist:(next)=>{ctx.watch=next;return true;}};
 vm.createContext(ctx);vm.runInContext(code,ctx);return ctx;
}
const a=scenario([photo('long',0,4)]);a.autoImportScreenshots();
assert.equal(a.watch.length,4);assert.equal(a.photos[0].importedIds.length,4);
assert.equal(a.armCount,1);
a.autoImportScreenshots();assert.equal(a.watch.length,4);assert.equal(a.armCount,1,'repeat cannot re-arm duplicates');
const b=scenario(Array.from({length:12},(_,i)=>photo(`photo${i}`,i,1)));
b.autoImportScreenshots();assert.equal(b.watch.length,12);
assert.equal(new Set(b.watch.map(x=>x.id)).size,12);
assert.equal(b.photos.every(p=>p.importedIds.length===1),true);
const c=scenario([photo('batch',0,12)]);c.autoImportScreenshots();assert.equal(c.watch.length,12);
const d=scenario([photo('batch',0,12)]);
d.fixtureCandidates=()=>fixtures.slice(0,3);
d.autoImportScreenshots();assert.equal(d.watch.length,3);
assert.equal(d.photos[0].unmatched.length,9,'unverified matches are explicitly reported');
console.log('PASS: real HTML autoImportScreenshots adds 4/12 distinct matches, multiple photos, no duplicate/unsafe import');
