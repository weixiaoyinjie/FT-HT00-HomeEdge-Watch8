/* FT home-favoured, low-goal EXACT SCORE research engine v2.2.
   Historical Poisson is UNCALIBRATED and NEVER a verified trading edge.
   All offered prices must be actual, matched Bet365 FT correct-score prices. */
(function(root,factory){
  const engine=factory();
  if(typeof module==='object'&&module.exports)module.exports=engine;
  if(root)root.FTSelectorEngine=engine;
})(typeof window!=='undefined'?window:null,function(){
'use strict';
const COMBOS=[
 {id:'clean',name:'主队优势 · 低客球',scores:['1-0','2-0','1-1'],main:'1-0'},
 {id:'home-attack',name:'主队优势 · 第二球空间',scores:['1-0','2-0','2-1'],main:'1-0'},
 {id:'both-score',name:'主胜倾向 · 防平风险',scores:['1-0','1-1','2-1'],main:'1-0'},
 {id:'two-main',name:'主队两球倾向 · 客队可能破门',scores:['2-0','2-1','1-0'],main:'2-0'}
];
const pick=(x,lo,hi)=>Math.max(lo,Math.min(hi,x));
function poisson(l,k){if(k<0)return 0;let p=Math.exp(-l);for(let i=1;i<=k;i++)p*=l/i;return p;}
function scoreP(lh,la,score){const [h,a]=score.split('-').map(Number);return poisson(lh,h)*poisson(la,a);}
function overGoals(l,k){let s=0;for(let n=0;n<=k;n++)s+=poisson(l,n);return Math.max(0,1-s);}
function rate(rows,check){return rows.length?rows.filter(check).length/rows.length:null;}
function isFinished(f){return ['FT','AET','PEN'].includes(String(f?.fixture?.status?.short||''));}
function fullScore(f){const s=f?.score?.fulltime;let h=s?.home,a=s?.away;
 if(h==null||a==null){h=f?.goals?.home;a=f?.goals?.away;}
 if(!isFinished(f)||h==null||a==null||!Number.isFinite(Number(h))||!Number.isFinite(Number(a)))return null;
 return [Number(h),Number(a)];}
function gather(teamId,items,kickoff,venue){const at=Date.parse(kickoff),seen=new Set(),all=[];
 for(const f of items||[]){const id=String(f?.fixture?.id||''),t=Date.parse(f?.fixture?.date||'');
  if(!id||seen.has(id)||!Number.isFinite(t)||t>=at)continue;
  const s=fullScore(f);if(!s)continue;
  const home=Number(f?.teams?.home?.id)===Number(teamId),away=Number(f?.teams?.away?.id)===Number(teamId);
  if(!home&&!away)continue;
  if(f?.league?.type!=='League'||/friendly|u\s?\d\d|youth|reserve|amateur|women|cup/i.test(f?.league?.name||''))continue;
  seen.add(id);all.push({id,t,home,gf:home?s[0]:s[1],ga:home?s[1]:s[0],total:s[0]+s[1]});
 }
 all.sort((a,b)=>b.t-a.t);
 const recent=all.slice(0,20),onSite=all.filter(x=>x.home===(venue==='home')).slice(0,10);
 const avg=(list,field)=>list.length?list.reduce((s,x)=>s+x[field],0)/list.length:null;
 const count=(list,fn)=>list.length?list.filter(fn).length/list.length:null;
 return {recent,onSite,n:recent.length,siteN:onSite.length,
  gf:avg(recent,'gf'),ga:avg(recent,'ga'),siteGF:avg(onSite,'gf'),siteGA:avg(onSite,'ga'),
  zeroRate:count(recent,x=>x.total===0),siteZero:count(onSite,x=>x.total===0),
  heavyRate:count(recent,x=>x.total>=4),siteHeavy:count(onSite,x=>x.total>=4),
  exactOneRate:count(onSite,x=>x.gf===1),twoRate:count(onSite,x=>x.gf===2),
  scorelessRate:count(onSite,x=>x.gf===0),threePlusRate:count(onSite,x=>x.gf>=3),
  concedeZero:count(onSite,x=>x.ga===0),concedeOne:count(onSite,x=>x.ga===1),
  concedeTwoPlus:count(onSite,x=>x.ga>=2),concedeThreePlus:count(onSite,x=>x.ga>=3),
  lowTotalRate:count(onSite,x=>x.total>=1&&x.total<=3),
  goals:recent.map(x=>[x.gf,x.ga])};
}
function normalizedPrice(quote){const n=Number(quote?.odd);return quote?.bookmaker==='Bet365'&&Number.isFinite(n)&&n>1?n:null;}
function oddsExtract(rows,exactIds){
 const quotes={},other={home:null,draw:null,away:null,under35:null,over35:null};
 for(const row of rows||[])for(const book of row.bookmakers||[]){
  if(!/\bbet\s*365\b/i.test(book.name||''))continue;
  for(const bet of book.bets||[]){const name=String(bet.name||'').toLowerCase();
   const isHalf=/half|1st|first|ht|2nd/i.test(name);
   const exact=!isHalf&&(exactIds.includes(Number(bet.id)) || /correct\s*score|exact\s*score/.test(name));
   if(exact)for(const v of bet.values||[]){const m=String(v.value||'').replace(/\s/g,'').match(/^(\d{1,2})[-:](\d{1,2})$/),odd=Number(v.odd);
    if(m&&Number.isFinite(odd)&&odd>1)quotes[Number(m[1])+'-'+Number(m[2])]={odd,bookmaker:'Bet365'};
   }
   if(/^(match winner|1x2|full time result|match result)$/.test(name))for(const v of bet.values||[]){const odd=Number(v.odd);if(!Number.isFinite(odd)||odd<=1)continue;
    const s=String(v.value||'').toLowerCase();if(/home|^1$/.test(s))other.home=odd;else if(/draw|^x$/.test(s))other.draw=odd;else if(/away|^2$/.test(s))other.away=odd;
   }
   if(/over\s*\/\s*under|total goals|goals o\/u/.test(name)&&!/half|1st|first|corner|card|team/i.test(name))for(const v of bet.values||[]){const s=String(v.value||'').toLowerCase(),odd=Number(v.odd);if(!Number.isFinite(odd)||odd<=1)continue;
    if(/under\s*3[.,]5/.test(s))other.under35=odd;
    if(/over\s*3[.,]5/.test(s))other.over35=odd;
   }
  }
 }
 return {quotes,other};
}
function analyze(input){
 const f=input.fixture||{},start=f?.fixture?.date,homeId=f?.teams?.home?.id,awayId=f?.teams?.away?.id;
 const home=gather(homeId,input.homeHistory,start,'home'),away=gather(awayId,input.awayHistory,start,'away');
 const odds=oddsExtract(input.oddsRows,input.exactBetIds||[]);
 const hard=[],watch=[];
 // Full-time thresholds are research filters, NOT calibrated probabilities.
 const minOdd=input.ignorePriceFloor===true?1.00001:(Number.isFinite(Number(input.minOdd))?Math.max(4,Number(input.minOdd)):4);
 if(f?.fixture?.status?.short!=='NS')hard.push('仅支持赛前筛选');
 if(f?.league?.type!=='League'||/friendly|youth|reserve|amateur|u\s?\d\d|women/i.test(f?.league?.name||''))hard.push('杯赛/青年/友谊赛或动机不稳，默认PASS');
 if(home.n<10||away.n<10||home.siteN<5||away.siteN<5)watch.push('近20场或主客场样本不足，不能形成A/B候选');
 const missing=!Number.isFinite(home.gf)||!Number.isFinite(away.ga)||!Number.isFinite(away.gf)||!Number.isFinite(home.ga);
 if(missing)return {grade:'PASS',reason:['真实历史资料缺失',...hard,...watch].join('；'),home,away,combos:[],odds};
 const H=(home.siteN>=5?home.siteGF*.7+home.gf*.3:home.gf),D=(away.siteN>=5?away.siteGA*.7+away.ga*.3:away.ga);
 const A=(away.siteN>=5?away.siteGF*.7+away.gf*.3:away.gf),C=(home.siteN>=5?home.siteGA*.7+home.ga*.3:home.ga);
 const lh=pick(.5*(H+D)*.82 + .18*1.35,.3,2.8),la=pick(.5*(A+C)*.82 + .18*1.05,.2,2.5);
 const total=lh+la,p00=scoreP(lh,la,'0-0'),p4=overGoals(total,3),p5=overGoals(total,4);
 const pLow13=poisson(total,1)+poisson(total,2)+poisson(total,3);
 const homeWin=(()=>{let out=0;for(let h=1;h<=9;h++)for(let a=0;a<h;a++)out+=poisson(lh,h)*poisson(la,a);return out})();
 if(p00>=.18)hard.push('全场0-0模型风险偏高 '+Math.round(100*p00)+'%');
 else if(p00>=.13)watch.push('0-0风险仍不可忽略');
 if(home.siteZero!=null&&away.siteZero!=null&&home.siteN>=6&&away.siteN>=6&&home.siteZero>=.25&&away.siteZero>=.25)hard.push('双方近期主客场0-0集中');
 if(lh-la<.40||homeWin<.48)hard.push('主场优势不足，不能为了主场优先强行选1-0');
 if(la>1.14)hard.push('客队预计进球偏多，守住低比分难度高');
 if(total>2.80||p4>=.31||p5>=.16||pLow13<.62)hard.push('不符合全场1–3球为主的低比分结构，4球以上风险偏高');
 // The zero-goal match estimate alone misses a home attack that often blanks.
 if(home.siteN>=7&&away.siteN>=7&&home.scorelessRate>=.30&&away.concedeZero>=.35)
  hard.push('主队主场经常无法进球，且客队客场零失球较多；1-0主单不稳');
 else if(home.siteN>=7&&home.scorelessRate>=.25)
  watch.push('主队主场零进球频率偏高，警惕最终0-0或0-1');
 if(home.siteN>=7&&home.exactOneRate+home.twoRate<.38)
  hard.push('主队主场恰好1球/2球分布过少，不适合低比分主单');
 else if(home.siteN>=7&&home.exactOneRate+home.twoRate<.52)
  watch.push('主队主场恰好进1–2球证据偏弱');
 if(home.siteN>=7&&home.threePlusRate>=.37)
  hard.push('主队主场3球及以上较频繁，比分易超出三张低分组合');
 if(away.siteN>=7&&away.concedeThreePlus>=.35)
  hard.push('客队客场经常失3球以上，可能出现3-0/3-1溢出风险');
 if(away.siteN>=7&&home.siteN>=7&&away.siteGF>1.2&&home.siteGA>1.0)
  hard.push('客队客场进攻与主队主场失球同时偏高，存在开放对攻风险');
 if(home.siteHeavy!=null&&away.siteHeavy!=null&&home.siteN>=6&&away.siteN>=6&&(home.siteHeavy>=.45||away.siteHeavy>=.45))hard.push('近期主/客场多球风险高');
 const market=odds.other,over35=market.over35&&market.under35?
  (1/market.over35)/(1/market.over35+1/market.under35):null;
 const homeMarket=market.home&&market.draw&&market.away?
  (1/market.home)/(1/market.home+1/market.draw+1/market.away):null;
 if(over35!=null&&over35>=.34)hard.push('Bet365全场3.5大球市场偏高，不符合低比分目标');
 if(homeMarket!=null&&homeMarket<.46)hard.push('Bet365胜平负不支持明显主场优势');
 if(over35==null)watch.push('没有可核对的Bet365全场3.5大小球市场，降级观察');
 if(homeMarket==null)watch.push('没有可核对的Bet365全场胜平负市场，降级观察');
 // Score the three-slip structure using both the Poisson scenario and
 // observable venue frequency. Empirical signals only resolve close calls;
 // they must NOT be represented as calibrated probabilities.
 function comboFit(c){
  const enough=home.siteN>=7&&away.siteN>=7;
  if(!enough)return 0;
  const h1=home.exactOneRate,h2=home.twoRate;
  const a1=away.concedeOne,a2=away.concedeTwoPlus;
  const aScoresOne=away.exactOneRate;
  if(c.id==='clean')return h1>=h2&&a1>=a2?.010:0;
  if(c.id==='home-attack')return h2>=.33&&a2>=.32&&aScoresOne>=.22?.030:0;
  if(c.id==='both-score')return la>=.93&&aScoresOne>=.40&&home.concedeOne>=.25?.014:0;
  if(c.id==='two-main')return h2>=.38&&h2>=h1*1.10&&a2>=.33?.017:0;
  return 0;
 }
 const combos=COMBOS.map(c=>{
  const items=c.scores.map(score=>({score,probability:scoreP(lh,la,score),odd:normalizedPrice(odds.quotes[score]),bookmaker:'Bet365'}));
  const coverage=items.reduce((s,x)=>s+x.probability,0),allPriced=items.every(x=>x.odd!=null&&x.odd>=minOdd);
  const mainP=scoreP(lh,la,c.main),bestOther=Math.max(...items.filter(x=>x.score!==c.main).map(x=>x.probability));
  const twoMainSupported=c.main!=='2-0'||(home.siteN>=7&&home.twoRate>=.38&&home.twoRate>=home.exactOneRate*1.10&&mainP>=scoreP(lh,la,'1-0')*.90);
  const reasonableMain=mainP>=bestOther*.82&&twoMainSupported;
  const supportBonus=comboFit(c);
  return {...c,items,coverage,allPriced,mainP,reasonableMain,supportBonus,fitScore:coverage+supportBonus};
 }).sort((a,b)=>b.fitScore-a.fitScore);
 const good=combos.filter(x=>x.allPriced&&x.reasonableMain);
 const top=good[0]||combos[0], grade=hard.length?'PASS':!good.length?'C':watch.length?'C':
  home.n>=16&&away.n>=16&&home.siteN>=8&&away.siteN>=8&&p00<.12&&p4<.25?'A':'B';
 if(!hard.length&&!good.length)watch.push(input.ignorePriceFloor===true?'三张Bet365全场正确比分报价不齐或主单分布不成立，仅供观察':'三张Bet365全场正确比分报价不齐、低于最低赔率或主单分布不成立，禁止勾选');
 if(grade==='A')watch.push('A级仅表示静态条件一致；赛前阵容尚未由本模型核实');
 const siteProfiles=home.siteN>=7&&away.siteN>=7?
  '主队主场恰好1球'+Math.round(home.exactOneRate*100)+'%、恰好2球'+Math.round(home.twoRate*100)+'%；客队客场失2球及以上'+Math.round(away.concedeTwoPlus*100)+'%':
  '主客场频率样本不足';
 return {grade,reason:[...hard,...watch,siteProfiles].join('；')||'主场低进球与Bet365交叉盘口一致；概率未经校准',
  fit:{lh,la,total,p00,p4,p5,pLow13,homeWin,over35,homeMarket},home,away,combo:top,combos,odds,
  canSelect:['A','B'].includes(grade)&&top.allPriced};
}
return {COMBOS,poisson,scoreP,overGoals,gather,oddsExtract,analyze};
});
