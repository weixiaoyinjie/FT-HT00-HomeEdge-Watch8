/* FT-Half00-HomeEdge v1.0: two-stage historical research, NOT a calibrated probability model.
 * Stage 1: look for HT 0-0 with true historical HT scores and genuine Bet365 HT quotes.
 * Stage 2: estimate conditional SECOND-HALF goals given HT 0-0; rank FT low scores.
 * Full-time score quotes never substitute for half-time prices (and vice versa).
 */
(function(root,factory){const e=factory();if(typeof module==='object'&&module.exports)module.exports=e;if(root)root.FTHalf00Engine=e;})(typeof window!=='undefined'?window:null,function(){
'use strict';
const clip=(x,min,max)=>Math.max(min,Math.min(max,x));
const mean=(arr,key)=>arr.length?arr.reduce((a,b)=>a+(typeof key==='function'?key(b):b[key]),0)/arr.length:null;
const fraction=(arr,fn)=>arr.length?arr.filter(fn).length/arr.length:null;
const poi=(x,n)=>{if(n<0)return 0;let p=Math.exp(-x);for(let i=1;i<=n;i++)p*=x/i;return p;};
const prob=(lh,la,score)=>{let [h,a]=score.split('-').map(Number);return poi(lh,h)*poi(la,a);};
const tail=(x,from)=>{let p=0;for(let i=0;i<from;i++)p+=poi(x,i);return 1-p;};
const fin=new Set(['FT','AET','PEN']);
const riskName=/friendly|youth|reserve|amateur|u[- ]?(?:16|17|18|19|20|21|22|23)\b|cup|copa|women|supercup/i;
function profile(id,fixtures,kickoff,venue){
 const at=Date.parse(kickoff),seen=new Set(),out=[];
 for(const f of fixtures||[]){const fixtureId=String(f?.fixture?.id||''),t=Date.parse(f?.fixture?.date||'');
  if(!fixtureId||seen.has(fixtureId)||!Number.isFinite(t)||t>=at||!fin.has(String(f?.fixture?.status?.short||'')))continue;
  const atHome=Number(f?.teams?.home?.id)===Number(id),atAway=Number(f?.teams?.away?.id)===Number(id);
  if(!atHome&&!atAway||f?.league?.type!=='League'||riskName.test(f?.league?.name||''))continue;
  const h=f?.score?.halftime,a=f?.score?.fulltime;
  if(!Number.isFinite(Number(h?.home))||!Number.isFinite(Number(h?.away))||!Number.isFinite(Number(a?.home))||!Number.isFinite(Number(a?.away))||
   h?.home==null||h?.away==null||a?.home==null||a?.away==null)continue;
  const htH=Number(h.home),htA=Number(h.away),ftH=Number(a.home),ftA=Number(a.away);
  if(Math.min(htH,htA,ftH,ftA)<0||ftH<htH||ftA<htA)continue;
  seen.add(fixtureId);
  const hf=atHome?htH:htA,ha=atHome?htA:htH,ff=atHome?ftH:ftA,fa=atHome?ftA:ftH;
  out.push({id:fixtureId,t,home:atHome,htFor:hf,htAgainst:ha,ftFor:ff,ftAgainst:fa,
   shFor:ff-hf,shAgainst:fa-ha,ht00:hf===0&&ha===0,ft00:ff===0&&fa===0});
 }
 out.sort((a,b)=>b.t-a.t);
 const recent=out.slice(0,20),site=out.filter(x=>x.home===(venue==='home')).slice(0,10),cond=site.filter(x=>x.ht00);
 return {n:recent.length,siteN:site.length,condN:cond.length,
  ht00:fraction(site,x=>x.ht00),recent00:fraction(recent,x=>x.ht00),
  htGF:mean(site,'htFor'),htGA:mean(site,'htAgainst'),
  shGF:mean(site,'shFor'),shGA:mean(site,'shAgainst'),
  condGF:mean(cond,'shFor'),condGA:mean(cond,'shAgainst'),
  condFt00:fraction(cond,x=>x.ft00),condExactlyOne:fraction(cond,x=>x.shFor===1),
  condGoalsAtLeast3:fraction(cond,x=>x.shFor+x.shAgainst>=3),
  htFirst15Unavailable:true, // /fixtures score.halftime alone cannot determine goal minutes.
  lastSeven:site.slice(0,7).map(x=>({ht:x.htFor+'-'+x.htAgainst,ft:x.ftFor+'-'+x.ftAgainst,ht00:x.ht00})),
  recent,site};
}
const oddOf=v=>{const n=Number(v?.odd);return Number.isFinite(n)&&n>1?n:null};
function markets(rows,ids={}){
 const ht={zero:null,under05:null,over05:null,under15:null,over15:null,draw:null,home:null,away:null},
 ft={quotes:{},home:null,draw:null,away:null,under35:null,over35:null};
 const isHalf=n=>/(?:\b1st\b|\bfirst\b|\bhalf[ -]?time\b|\b1h\b|\bht\b)/i.test(n);
 for(const row of rows||[])for(const book of row.bookmakers||[]){if(!/\bbet\s*365\b/i.test(book.name||''))continue;
  for(const b of book.bets||[]){const name=String(b.name||'').toLowerCase().replace(/[_–—]/g,' '),id=Number(b.id),half=isHalf(name);
   const halfExact=(ids.htExactIds||[]).includes(id)||(half&&/correct\s*score|exact\s*score/i.test(name));
   const fullExact=(ids.ftExactIds||[]).includes(id)||(!half&&/correct\s*score|exact\s*score/i.test(name));
   if(halfExact)for(const v of b.values||[]){const val=String(v.value||'').replace(/\s/g,''),odd=oddOf(v);if(val.match(/^0[-:]0$/)&&odd!=null)ht.zero=odd;}
   if(fullExact)for(const v of b.values||[]){const m=String(v.value||'').replace(/\s/g,'').match(/^(\d{1,2})[-:](\d{1,2})$/),odd=oddOf(v);if(m&&odd!=null)ft.quotes[Number(m[1])+'-'+Number(m[2])]={odd,bookmaker:'Bet365'};}
   const halfOU=(ids.htOUIds||[]).includes(id)||(half&&/over\s*\/\s*under|total\s*goals|goals\s*o\/u/i.test(name));
   if(halfOU)for(const v of b.values||[]){const val=String(v.value||'').toLowerCase(),odd=oddOf(v);if(odd==null)continue;
    if(/under\s*0[.,]5/.test(val))ht.under05=odd;if(/over\s*0[.,]5/.test(val))ht.over05=odd;
    if(/under\s*1[.,]5/.test(val))ht.under15=odd;if(/over\s*1[.,]5/.test(val))ht.over15=odd;
   }
   const halfWin=(ids.htWinIds||[]).includes(id)||(half&&/winner|result|1\s*x\s*2/i.test(name)&&!/full\s*time|ht\s*\/\s*ft/i.test(name));
   const fullWin=(ids.ftWinIds||[]).includes(id)||(!half&&/^(match winner|1x2|match result|full time result)$/i.test(name));
   if(halfWin||fullWin)for(const v of b.values||[]){const val=String(v.value||'').toLowerCase(),odd=oddOf(v);if(odd==null)continue;
    const key=/^(home|1)$/.test(val)?'home':/^(draw|x)$/.test(val)?'draw':/^(away|2)$/.test(val)?'away':null;
    if(key)(halfWin?ht:ft)[key]=odd;
   }
   if(!half&&/over\s*\/\s*under|total\s*goals|goals\s*o\/u/i.test(name)&&!/team|corner|card/i.test(name))for(const v of b.values||[]){const s=String(v.value||'').toLowerCase(),odd=oddOf(v);if(odd==null)continue;
    if(/under\s*3[.,]5/.test(s))ft.under35=odd;if(/over\s*3[.,]5/.test(s))ft.over35=odd;
   }
  }
 }
 return {ht,ft};
}
function normalized(pairA,pairB){return pairA&&pairB?(1/pairA)/(1/pairA+1/pairB):null;}
const OPTIONS=[
 {name:'主队一球 · 0-0保险',scores:['1-0','0-0','2-0'],main:'1-0'},
 {name:'主队一球 · 平局保险',scores:['1-0','0-0','1-1'],main:'1-0'},
 {name:'主队一球 · 双方破门',scores:['1-0','1-1','2-1'],main:'1-0'},
 {name:'主队一球 · 第二球',scores:['1-0','2-0','1-1'],main:'1-0'}
];
function analyze({fixture,homeHistory,awayHistory,oddsRows,marketIds={}}){
 const f=fixture||{},home=profile(f?.teams?.home?.id,homeHistory,f?.fixture?.date,'home'),away=profile(f?.teams?.away?.id,awayHistory,f?.fixture?.date,'away');
 const prices=markets(oddsRows,marketIds),hard=[],warnings=[];
 if(f?.fixture?.status?.short!=='NS')hard.push('仅允许赛前筛选');
 if(f?.league?.type!=='League'||riskName.test(f?.league?.name||''))hard.push('杯赛/友谊赛/青年队/不稳定赛事默认排除');
 if(home.n<10||away.n<10||home.siteN<5||away.siteN<5)warnings.push('至少需要双方各10场及对应主客场各5场有效半场＋全场赛果');
 if(home.siteN<3||away.siteN<3)return {grade:'PASS',reason:['缺少半场及全场完整历史',...hard,...warnings].join('；'),home,away,prices,fit:null,combos:[],combo:null};
 // 1. Historical HT 0-0 prior: venue frequency and a shrunk, independent first-half Poisson.
 const hExp=clip(.5*((home.htGF??.7)+(away.htGA??.7)),.12,2.1);
 const aExp=clip(.5*((away.htGF??.6)+(home.htGA??.6)),.10,1.9);
 const pPoi=Math.exp(-hExp-aExp);
 const pVenue=clip(.5*((home.ht00??.3)+(away.ht00??.3)),.01,.90);
 const pHT00=clip(.60*pPoi+.40*pVenue,.02,.85);
 const validCond=home.condN+away.condN;
 // 2. Second-half rates conditional on HT 0-0, shrunk toward normal second-half rates.
 // A team's own HT00 sample is not equivalent to this matchup; shrink heavily to limit overfitting.
 const shH=(home.shGF??1.05)*.5+(away.shGA??1.00)*.5;
 const shA=(away.shGF??.75)*.5+(home.shGA??.75)*.5;
 const conditionalH=Number.isFinite(home.condGF)&&Number.isFinite(away.condGA)?(home.condGF+away.condGA)/2:null;
 const conditionalA=Number.isFinite(away.condGF)&&Number.isFinite(home.condGA)?(away.condGF+home.condGA)/2:null;
 const wt=clip(Math.min(home.condN,away.condN)/10,0,.60);
 const lh=clip((1-wt)*shH+wt*(conditionalH??shH),.12,2.4);
 const la=clip((1-wt)*shA+wt*(conditionalA??shA),.10,2.2);
 const total=lh+la,pFt00=prob(lh,la,'0-0');
 const pHome=(()=>{let s=0;for(let h=1;h<=9;h++)for(let a=0;a<h;a++)s+=poi(lh,h)*poi(la,a);return s})();
 const pDraw=(()=>{let s=0;for(let i=0;i<=9;i++)s+=poi(lh,i)*poi(la,i);return s})();
 const pAway=1-pHome-pDraw,p3=tail(total,3),p4=tail(total,4);
 const htUnder05=normalized(prices.ht.under05,prices.ht.over05);
 const htMarket00=prices.ht.zero?1/prices.ht.zero:null; // raw bookmaker implied, WITHOUT removal of margin.
 const marketHome=prices.ft.home&&prices.ft.away&&prices.ft.draw?
  (1/prices.ft.home)/(1/prices.ft.home+1/prices.ft.draw+1/prices.ft.away):null;
 const marketOver35=normalized(prices.ft.over35,prices.ft.under35);
 const observedFT00=(home.condN>=3&&away.condN>=3)?(home.condFt00+away.condFt00)/2:null;
 const fit={htExpH:hExp,htExpA:aExp,pHT00,venue00:pVenue,poisson00:pPoi,htMarket00,htUnder05,
  lh,la,secondHalfTotal:total,pFt00,p00:pFt00,pHome,pAway,pDraw,p3,p4,marketHome,marketOver35,
  pJoint10:pHT00*prob(lh,la,'1-0'),pJoint00:pHT00*pFt00,observedFT00};
 // STAGE ONE: HT 0-0 is a required screen, not a risk to reject automatically.
 if(pHT00<.32)hard.push('第一阶段不满足上半场0-0倾向（低于32%研究门槛）');
 else if(pHT00<.40)warnings.push('半场0-0倾向尚未达到重点高概率观察线40%');
 if(home.siteN>=6&&away.siteN>=6&&home.ht00<.20&&away.ht00<.20)hard.push('双方同场地历史半场0-0频率都低');
 if(prices.ht.zero==null)warnings.push('没有真实Bet365半场0-0正确比分报价，禁止升A/B');
 if(prices.ht.zero!=null&&Math.abs(pHT00-htMarket00)>.18)warnings.push('历史模型和半场0-0赔率隐含概率明显冲突');
 if(htUnder05!=null&&Math.abs(pHT00-htUnder05)>.17)warnings.push('半场0.5大小球去水市场与历史模型冲突');
 if(prices.ht.under15==null)warnings.push('半场1.5小球市场未提供，交叉验证较弱');
 // STAGE TWO: only consider if a home-team lead after HT 0-0 is plausible.
 if(validCond<5||home.condN<2||away.condN<2)warnings.push('双方对应主客场半场0-0后的下半场样本不足');
 if(lh-la<.30||pHome<.39)hard.push('第二阶段主队下半场取胜优势不足');
 if(la>1.00||pAway>.31)hard.push('下半场客队进球/反超风险偏高');
 if(total>2.30||p3>.40||p4>.21)hard.push('下半场可能多球，无法聚焦全场低比分');
 if(observedFT00!=null&&observedFT00>=.47)hard.push('历史半场0-0后最终仍0-0比例偏高，不强推主队1-0');
 else if(observedFT00!=null&&observedFT00>=.32)warnings.push('双方历史半场0-0后最终仍0-0不低，需人工复核');
 if(pFt00>=.43)hard.push('半场0-0之后最终仍0-0占主导，不强推1-0');
 else if(pFt00>=.31)warnings.push('半场0-0后全场0-0仍是重要风险，不能因为主场优势忽略');
 if(marketHome!=null&&marketHome<.42)hard.push('Bet365全场胜平负不支持明确主场优势');
 else if(marketHome==null)warnings.push('缺少Bet365全场1X2去水验证');
 if(marketOver35!=null&&marketOver35>=.34)hard.push('Bet365全场3.5大球偏高，低比分证据冲突');
 else if(marketOver35==null)warnings.push('缺少全场3.5大小球市场验证');
 const combos=OPTIONS.map(c=>{
  const items=c.scores.map(score=>({score,probability:prob(lh,la,score),joint:pHT00*prob(lh,la,score),odd:prices.ft.quotes[score]?.odd??null}));
  const coverage=items.reduce((s,x)=>s+x.probability,0),allPriced=items.every(x=>x.odd!=null);
  const mainP=prob(lh,la,'1-0'),fitMain=mainP>=pFt00*.85&&mainP>=prob(lh,la,'0-1')*1.25;
  const balanceBonus=c.scores.includes('0-0')&&pFt00>=.22?.015:0;
  return {...c,items,coverage,allPriced,reasonableMain:fitMain,fitScore:coverage+balanceBonus};
 }).sort((a,b)=>b.fitScore-a.fitScore);
 const good=combos.filter(c=>c.allPriced&&c.reasonableMain);
 const combo=good[0]||combos[0];
 if(!good.length)warnings.push('三张全场真实比分赔率不齐，或1-0未达到结构门槛');
 const criticalMarket=prices.ht.zero!=null&&prices.ft.home!=null&&prices.ft.draw!=null&&prices.ft.away!=null;
 let grade=hard.length?'PASS':(!criticalMarket||!good.length||home.siteN<6||away.siteN<6||home.condN<2||away.condN<2)?'C':
  pHT00>=.45&&pFt00<.31&&pHome>=.47&&home.condN>=4&&away.condN>=4&&warnings.length<=2?'A':'B';
 if(!hard.length&&warnings.some(s=>/明显冲突/.test(s)))grade='C';
 const reasons=[...hard,...warnings,`半场0-0：历史泊松${(pPoi*100).toFixed(1)}% / 同场地经验${(pVenue*100).toFixed(1)}% / 综合${(pHT00*100).toFixed(1)}%`,
  `半场0-0后的下半场条件估计 主${lh.toFixed(2)}球/客${la.toFixed(2)}球，最终0-0 ${ (pFt00*100).toFixed(1)}%`,
  `双方同场地0-0转全场样本 主${home.condN}场/客${away.condN}场；阈值均需赛后回测`];
 return {grade,reason:reasons.join('；'),home,away,prices,fit,combos,combo,
  canSelect:['A','B'].includes(grade),diagnostics:{hard,warnings},
  observed:{htPrice:prices.ht.zero,ftQuotes:prices.ft.quotes}};
}
return {profile,markets,analyze,prob,poi,tail,OPTIONS};
});
