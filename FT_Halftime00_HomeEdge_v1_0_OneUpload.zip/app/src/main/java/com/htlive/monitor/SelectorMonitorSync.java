package com.htlive.monitor;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import org.json.JSONArray;
import org.json.JSONObject;
import java.time.OffsetDateTime;
import java.util.LinkedHashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/** One-tap scanner -> existing ScorePath monitoring service. No bet/settlement actions. */
public final class SelectorMonitorSync {
    private static final String PREF = "ht_monitor", SELECTOR = "selectorMatches";
    private SelectorMonitorSync(){}
    private static JSONArray items(SharedPreferences p){
        try{return new JSONArray(p.getString(SELECTOR,"[]"));}
        catch(Exception ignored){return new JSONArray();}
    }
    private static String csv(Iterable<String> ids){
        StringBuilder b=new StringBuilder();for(String id:ids){if(b.length()>0)b.append(',');b.append(id);}return b.toString();
    }
    private static LinkedHashMap<String,JSONObject> map(JSONArray a){
        LinkedHashMap<String,JSONObject> out=new LinkedHashMap<>();
        for(int i=0;i<a.length();i++){
            JSONObject x=a.optJSONObject(i);if(x==null)continue;
            String id=x.optString("id");if(id.matches("[0-9]{1,12}"))out.put(id,x);
        }return out;
    }
    private static Set<String> split(String csv){
        Set<String> out=new java.util.LinkedHashSet<>();
        if(csv!=null)for(String id:csv.split(","))if(id.matches("[0-9]{1,12}"))out.add(id);
        return out;
    }
    private static String reply(boolean ok,String status,String message){
        return new JSONObjectBuilder().put("ok",ok).put("status",status).put("message",message).toString();
    }
    private static final class JSONObjectBuilder{
        private final JSONObject data=new JSONObject();
        JSONObjectBuilder put(String k,Object v){try{data.put(k,v);}catch(Exception ignored){}return this;}
        @Override public String toString(){return data.toString();}
    }
    public static String period(Context ctx,String id){
        // FT-only independent app: also interpret manually imported fixtures as full-time.
        // The previous HT app is a different package and keeps its own original rules.
        return "FT";
    }
    public static boolean fullTime(Context ctx,String id){return "FT".equals(period(ctx,id));}
    static Set<String> selectedFixtureIds(Context ctx){
        return new HashSet<>(map(items(ctx.getSharedPreferences(PREF,Context.MODE_PRIVATE))).keySet());
    }
    static boolean isSelectedFixture(Context ctx,String id){
        return selectedFixtureIds(ctx).contains(id);
    }
    public static String selectedIds(Context ctx){
        JSONArray result=new JSONArray();
        for(String id:map(items(ctx.getSharedPreferences(PREF,Context.MODE_PRIVATE))).keySet())result.put(id);
        return result.toString();
    }
    public static String selectorMatches(Context ctx){
        return items(ctx.getSharedPreferences(PREF,Context.MODE_PRIVATE)).toString();
    }
    /** Existing monitor UI may remove a managed fixture. Respect that removal. */
    public static void pruneToWatchlist(Context ctx,String requestedCsv){
        SharedPreferences p=ctx.getSharedPreferences(PREF,Context.MODE_PRIVATE);
        Set<String> requested=split(requestedCsv);
        LinkedHashMap<String,JSONObject> old=map(items(p));
        JSONArray filtered=new JSONArray();
        for(Map.Entry<String,JSONObject> entry:old.entrySet())
            if(requested.contains(entry.getKey()))filtered.put(entry.getValue());
        p.edit().putString(SELECTOR,filtered.toString()).apply();
    }
    private static JSONObject validate(String raw) throws Exception{
        if(raw==null||raw.length()>12000)throw new Exception("比赛资料无效或过长");
        JSONObject entry=new JSONObject(raw);
        String id=entry.optString("id"),home=entry.optString("home"),away=entry.optString("away");
        String grade=entry.optString("grade"),main=entry.optString("main");
        String iso=entry.optString("kickoff");
        if(!id.matches("[0-9]{1,12}")||home.trim().isEmpty()||away.trim().isEmpty()||home.length()>120||away.length()>120)
            throw new Exception("比赛ID和双方球队不完整");
        if(!"A".equals(grade)&&!"B".equals(grade)&&!"C".equals(grade)&&!"PASS".equals(grade))
            throw new Exception("筛选评级无效");
        boolean observeOnly="C".equals(grade)||"PASS".equals(grade);
        String period="FT"; // FT-only independent companion
        JSONArray proposed=entry.optJSONArray("suggestedScores");
        if(!observeOnly){
            if(!"1-0".equals(main))throw new Exception("全场双阶段候选主单必须为1-0");
            if(entry.optBoolean("riskPass",true))throw new Exception("全场双阶段风险排雷未通过");
            if(!entry.has("ht00Model")||entry.isNull("ht00Model")||
                entry.optDouble("ht00Model",0)<.32||entry.optDouble("ht00Model",1)>.85)
                throw new Exception("第一阶段半场0-0概率不达研究门槛或无法核实");
            if(!entry.has("ht00Odd")||entry.isNull("ht00Odd")||entry.optDouble("ht00Odd",0)<=1.0)
                throw new Exception("未取得真实Bet365半场0-0赔率，不能作为A/B自动候选");
            if(!entry.has("secondHalfHomeWin")||entry.isNull("secondHalfHomeWin")||
                entry.optDouble("secondHalfHomeWin",0)<.39)
                throw new Exception("第二阶段主队下半场优势未通过");
            if(!entry.has("zeroModel")||entry.isNull("zeroModel")||entry.optDouble("zeroModel",1)>=.43)
                throw new Exception("半场0-0后全场0-0条件风险过高");
            if(proposed==null||proposed.length()!=3)throw new Exception("全场必须恰好三张不同的研究比分");
            Set<String> unique=new HashSet<>();
            for(int k=0;k<3;k++){
                String sc=proposed.optString(k,"");
                if(!ScoreGuardEngine.validPick(sc)||!unique.add(sc))throw new Exception("全场比分组合无效或重复");
            }
            if(!unique.contains(main))throw new Exception("全场主单必须属于三张比分组合");
        }
        long kickoff;
        try{kickoff=OffsetDateTime.parse(iso).toInstant().toEpochMilli();}
        catch(Exception ex){throw new Exception("比赛开赛时间无效");}
        if(kickoff<System.currentTimeMillis()-("FT".equals(period)?130L:55L)*60_000L)throw new Exception("对应模式的比赛观察窗口已结束，不能启动");
        if(kickoff>System.currentTimeMillis()+50L*24*3600_000L)throw new Exception("超过50天的比赛尚不能预约");
        JSONObject clean=new JSONObject();
        clean.put("id",id).put("home",home).put("away",away)
             .put("league",entry.optString("league","").substring(0,Math.min(entry.optString("league","").length(),120)))
             .put("kickoff",iso).put("grade",grade).put("main",observeOnly?"":main).put("period",period)
             .put("observeOnly",observeOnly)
             .put("ticketCount",3).put("suggestedScores",observeOnly?new JSONArray():proposed==null?new JSONArray():proposed).put("source","selector")
             .put("backup",entry.optString("backup","")).put("zeroOdd",entry.optDouble("zeroOdd",0))
             .put("zeroModel",entry.optDouble("zeroModel",1))
             .put("ht00Model",entry.optDouble("ht00Model",0))
             .put("ht00Odd",entry.optDouble("ht00Odd",0))
             .put("secondHalfHomeWin",entry.optDouble("secondHalfHomeWin",0));
        return clean;
    }
    public static synchronized String setSelected(Context ctx,String raw,boolean checked,String key){
        try{
            // For unchecked items, require only a valid fixture identifier.
            JSONObject incoming=checked?validate(raw):new JSONObject(raw);
            String id=incoming.optString("id");
            if(!id.matches("[0-9]{1,12}"))return reply(false,"ERROR","比赛ID无效");
            SharedPreferences p=ctx.getSharedPreferences(PREF,Context.MODE_PRIVATE);
            LinkedHashMap<String,JSONObject> before=map(items(p));
            LinkedHashMap<String,JSONObject> after=new LinkedHashMap<>(before);
            if(checked && before.containsKey(id) &&
                !incoming.optString("period","HT").equals(before.get(id).optString("period","HT")))
                return reply(false,"ERROR","同一场比赛已有另一模式监控，请先从原模式取消勾选后再切换");
            if(checked)after.put(id,incoming);else after.remove(id);
            Set<String> merged=split(p.getString("watchIds",""));
            // Remove the IDs formerly managed by the selector, then add current ones.
            merged.removeAll(before.keySet());merged.addAll(after.keySet());
            if(merged.size()>12)return reply(false,"ERROR","最多同时监控12场；请先减少其他预警场次");
            String useKey=(key==null?"":key.trim());
            if(checked&&useKey.isEmpty())useKey=p.getString("apiKey","").trim();
            if(checked&&useKey.isEmpty())return reply(false,"ERROR","请在筛选页设置API-FOOTBALL Key后再勾选");
            if(useKey.length()>1024)return reply(false,"ERROR","API Key过长");
            JSONArray stored=new JSONArray();for(JSONObject x:after.values())stored.put(x);
            SharedPreferences.Editor changes=p.edit().putString(SELECTOR,stored.toString())
                .putString("watchIds",csv(merged));
            if(checked)changes.putString("apiKey",useKey);
            if(merged.isEmpty())changes.putBoolean("autoArmFromImage",false);
            else if(!after.isEmpty())changes.putBoolean("autoArmFromImage",true);
            if(!changes.commit())return reply(false,"ERROR","本机保存监控数据失败");
            // Preserve original manually imported match reminders alongside selector selections.
            LinkedHashMap<String,JSONObject> alarms=map(new JSONArray(p.getString("alarm_watch","[]")));
            alarms.keySet().removeAll(before.keySet());
            for(Map.Entry<String,JSONObject> x:after.entrySet())alarms.put(x.getKey(),x.getValue());
            JSONArray scheduled=new JSONArray();
            for(JSONObject x:alarms.values())if(merged.contains(x.optString("id")))scheduled.put(x);
            ReminderReceiver.schedule(ctx,scheduled.toString());
            if(merged.isEmpty()){
                try{ctx.startService(new Intent(ctx,MonitorService.class).setAction("STOP"));}catch(Exception ignored){}
                return reply(true,"STOPPED","已取消监控，且当前监控列表为空");
            }
            if(!checked)return reply(true,"UPDATED","已从筛选预警名单移除；其他比赛继续监控");
            long kick=OffsetDateTime.parse(incoming.getString("kickoff")).toInstant().toEpochMilli();
            long now=System.currentTimeMillis();
            // Selecting a fixture queues it; do not start polling until scheduled kickoff+3'.
            // If another fixture is already being polled, MonitorService gates this
            // selector fixture by actual API status 1H && elapsed >= 3.
            if(SelectorStartPolicy.startDue(now,kick)){
                try{
                    Intent start=new Intent(ctx,MonitorService.class).setAction("START");
                    if(Build.VERSION.SDK_INT>=26)ctx.startForegroundService(start);else ctx.startService(start);
                    return reply(true,"STARTED","已勾选；预计开赛时间已过第3分钟，已请求开启对应半场/全场预警；实际须API确认比赛≥3分钟");
                }catch(Exception e){return reply(true,"BLOCKED","已保存比赛，但系统阻止启动；请打开预警页检查通知权限和后台运行");}
            }
            return reply(true,"ARMED","已勾选并锁定比赛模式，预约开赛后第3分钟启动；不会提前发送该场预警（系统省电可能延迟）");
        }catch(Exception e){return reply(false,"ERROR",e.getMessage()==null?"操作失败":e.getMessage());}
    }
}
