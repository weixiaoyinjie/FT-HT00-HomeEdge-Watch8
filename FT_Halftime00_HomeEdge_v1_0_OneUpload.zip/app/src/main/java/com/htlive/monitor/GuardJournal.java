package com.htlive.monitor;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;

/** Durable on-device review trail, kept even after a match is pruned at HT. */
public final class GuardJournal {
    private GuardJournal() {}
    public static synchronized void append(Context ctx,String id,String event,JSONObject match,long at){
        try{
            SharedPreferences p=ctx.getSharedPreferences("ht_monitor",Context.MODE_PRIVATE);
            JSONArray old=new JSONArray(p.getString("guardJournal","[]")),newLog=new JSONArray();
            JSONObject row=new JSONObject().put("id",id).put("time",at).put("event",event);
            if(match!=null){
                row.put("home",match.optString("home")).put("away",match.optString("away"))
                    .put("minute",match.optInt("minute",-1))
                    .put("score",match.optInt("h",-1)+"-"+match.optInt("a",-1))
                    .put("status",match.optString("status","?"))
                    .put("trend",match.optString("trend",""));
                if(match.has("guardRisk"))row.put("guardRisk",match.get("guardRisk"));
                if(match.has("guardBets"))row.put("guardBets",match.get("guardBets"));
                JSONObject gw=match.optJSONObject("goalWarning");
                if(gw!=null){
                    JSONObject w=new JSONObject();
                    for(String name:new String[]{"three","five","ten"})
                        if(gw.has(name)&&!gw.isNull(name))w.put(name,gw.get(name));
                    row.put("windows",w);
                }
                JSONObject st=match.optJSONObject("stats");
                if(st!=null&&st.optBoolean("available"))row.put("stats",st);
            }
            newLog.put(row);
            for(int i=0;i<old.length()&&newLog.length()<160;i++)newLog.put(old.get(i));
            p.edit().putString("guardJournal",newLog.toString()).apply();
        }catch(Exception e){android.util.Log.w("HT","Unable to append guard journal",e);}
    }
    static synchronized void noteManual(Context ctx,String id,JSONArray portfolio){
        try{
            JSONObject match=new JSONObject().put("guardBets",portfolio);
            JSONObject state=new JSONObject(ctx.getSharedPreferences("ht_monitor",Context.MODE_PRIVATE).getString("snapshot","{}"));
            JSONArray matches=state.optJSONArray("matches");
            if(matches!=null)for(int i=0;i<matches.length();i++){
                JSONObject item=matches.optJSONObject(i);
                if(item!=null && id.equals(item.optString("id"))){match=item;match.put("guardBets",portfolio);break;}
            }
            append(ctx,id,"用户保存/更新手动结算记录",match,System.currentTimeMillis());
        }catch(Exception ignored){}
    }
}
