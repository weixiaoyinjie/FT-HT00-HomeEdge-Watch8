package com.htlive.monitor;

import org.json.JSONArray;
import org.json.JSONObject;

/**
 * Live first-half exact-score portfolio monitor.
 * Order of reasoning: reach target -> preserve hit target -> compare manual settlement.
 * The remaining clock changes feasibility/exposure, but never forces liquidation.
 * Ratings are evidence labels; they are NOT calibrated probabilities.
 */
public final class ScoreGuardEngine {
    private ScoreGuardEngine() {}

    public static boolean validPick(String s) { return s != null && s.matches("[0-9]-[0-9]"); }
    public static String selectionSignature(JSONArray bets){
        StringBuilder key=new StringBuilder();
        if(bets!=null)for(int i=0;i<Math.min(3,bets.length());i++){
            JSONObject b=bets.optJSONObject(i);
            if(b==null){key.append("#none;");continue;}
            key.append(i).append(':').append(b.optString("pick", ""))
              .append(':').append(b.optBoolean("closed",false)?'1':'0').append(';');
        }
        return key.toString();
    }
    public static String state(String target, int h, int a) {
        if (!validPick(target)) return "UNSET";
        int th=target.charAt(0)-'0',ta=target.charAt(2)-'0';
        if(h>th || a>ta)return "BROKEN";
        if(h==th && a==ta)return "HIT";
        return "PENDING";
    }
    private static double val(JSONObject o,String field) {
        if(o==null||!o.has(field)||o.isNull(field))return Double.NaN;
        double n=o.optDouble(field,Double.NaN);
        return Double.isFinite(n) && n>=0?n:Double.NaN;
    }
    private static boolean known(double d){return Double.isFinite(d);}
    private static String fmt(double n){return known(n)?String.valueOf(Math.round(n*100.0)/100.0):"未知";}
    private static double pressure(JSONObject s){
        double shots=val(s,"shots"),on=val(s,"on"),box=val(s,"box"),xg=val(s,"xg");
        if(!known(shots)||!known(on)||!known(box))return Double.NaN;
        return .35*shots+1.65*on+1.30*box+(known(xg)?3*Math.min(1,xg):0);
    }
    private static boolean active(JSONObject b){
        return b!=null && validPick(b.optString("pick","")) && !b.optBoolean("closed",false);
    }
    /** One-next-goal is a scenario, not a prediction; it must consider the entire 2/3-ticket portfolio. */
    private static JSONObject nextGoal(JSONArray bets,int h,int a,String direction)throws Exception{
        int nh=h+("HOME".equals(direction)?1:0),na=a+("AWAY".equals(direction)?1:0);
        int hit=0,pending=0,broken=0;StringBuilder matching=new StringBuilder();
        for(int i=0;i<Math.min(3,bets.length());i++){
            JSONObject bet=bets.optJSONObject(i);if(!active(bet))continue;
            String st=state(bet.optString("pick"),nh,na);
            if("HIT".equals(st)){
                hit++;if(matching.length()>0)matching.append("、");
                matching.append(bet.optString("role",i==0?"主单":"保险"))
                    .append(' ').append(bet.optString("pick"));
            }else if("PENDING".equals(st))pending++;else broken++;
        }
        return new JSONObject().put("score",nh+"-"+na).put("hit",hit)
            .put("pending",pending).put("broken",broken)
            .put("matched",matching.toString())
            .put("summary",hit>0?matching.toString()+"命中":pending>0?"尚无命中单，仍有待达比分":"全部剩余比分单失效");
    }
    private static JSONObject recentWindow(JSONObject now){
        JSONObject gw=now.optJSONObject("goalWarning");
        JSONObject x=gw==null?null:gw.optJSONObject("five");
        if(x==null&&gw!=null)x=gw.optJSONObject("three");
        if(x==null&&gw!=null)x=gw.optJSONObject("ten");
        if(x==null)x=now.optJSONObject("guardFast");
        return x;
    }
    private static boolean fresh(JSONObject now,long at){
        JSONObject s=now.optJSONObject("stats");long sampled=now.optLong("lastStatsAt",0L);
        return s!=null && s.optBoolean("available",false) && sampled>0
            && sampled<=at+5000 && at-sampled<=90000 && !now.has("dataError");
    }
    private static boolean attackEvidence(JSONObject side){
        if(side==null)return false;
        double shots=val(side,"shots"),on=val(side,"on"),box=val(side,"box"),xg=val(side,"xg");
        return known(shots)&&shots>=2 && ((known(on)&&known(box)&&on>=1&&box>=1) ||
                (known(box)&&box>=1&&known(xg)&&xg>=.25));
    }
    private static String timeContext(int minute){
        int reg=Math.max(0,45-minute);
        return "常规上半场约剩"+reg+"分钟（补时未知），时间仅用于评估实现/守住条件";
    }
    private static String timeContext(int minute,String period){
        if(!"FT".equals(period))return timeContext(minute);
        return "全场常规时间约剩"+Math.max(0,90-minute)+"分钟（补时未知），需复核下半场新增攻势";
    }

    public static JSONObject analyze(JSONObject now,JSONArray selected,long currentTime)throws Exception{
        if(selected==null)selected=new JSONArray();
        int h=now.optInt("h",-1),a=now.optInt("a",-1),minute=now.optInt("minute",0);
        String period=now.optString("period","HT");
        JSONObject output=new JSONObject().put("level","NONE").put("action","继续观察")
            .put("title","尚未填写比分单").put("reason","请先设置主单和保险单")
            .put("hit",0).put("pending",0).put("broken",0).put("closed",0)
            .put("evaluatedAt",currentTime).put("score",h+"-"+a)
            .put("remainingRegularMinutes",Math.max(0,("FT".equals(period)?90:45)-minute))
            .put("timeContext",timeContext(minute,period));
        if(h<0||a<0)return output;
        JSONArray bets=new JSONArray(),items=new JSONArray();
        for(int i=0;i<Math.min(3,selected.length());i++){
            JSONObject b=selected.optJSONObject(i);
            if(b!=null && validPick(b.optString("pick","")))bets.put(b);
        }
        int hit=0,pending=0,broken=0,closed=0;
        JSONObject recent=recentWindow(now);
        boolean validStats=fresh(now,currentTime);
        JSONObject homeDelta=validStats&&recent!=null?recent.optJSONObject("home"):null;
        JSONObject awayDelta=validStats&&recent!=null?recent.optJSONObject("away"):null;
        StringBuilder reach=new StringBuilder();
        boolean reachSupported=false,reachTight=false;
        int closest=99;
        for(int i=0;i<bets.length();i++){
            JSONObject b=bets.optJSONObject(i);String pick=b.optString("pick");
            int gh=pick.charAt(0)-'0',ga=pick.charAt(2)-'0';
            int needH=Math.max(0,gh-h),needA=Math.max(0,ga-a),needed=needH+needA;
            boolean done=b.optBoolean("closed",false);
            String st=done?"CLOSED":state(pick,h,a);
            if(done)closed++;else if("HIT".equals(st))hit++;else if("BROKEN".equals(st))broken++;else pending++;
            String reachLevel="NOT_APPLICABLE",reachReason="";
            if("PENDING".equals(st)){
                closest=Math.min(closest,needed);
                JSONObject side=needH>0?homeDelta:awayDelta;
                boolean supported=needed==1 && attackEvidence(side);
                boolean tight=("FT".equals(period)?(minute>=85&&needed>=1)||(minute>=80&&needed>=2):(minute>=41&&needed>=1)||(minute>=36&&needed>=2));
                reachSupported|=supported;
                reachTight|=tight;
                reachLevel=supported?"ATTACK_SUPPORTED":tight?"TIME_TIGHT":validStats&&recent!=null?"UNCONFIRMED":"DATA_MISSING";
                reachReason="还需主队"+needH+"球、客队"+needA+"球"+
                    (supported?"；所需进球方有新的禁区/射正证据":tight?"；剩余常规时间较短，补时未知":"；尚无足够证据证实能够达到");
                if(reach.length()>0)reach.append("；");
                reach.append(b.optString("role",i==0?"主单":"保险")).append(' ')
                    .append(pick).append(' ').append(reachReason);
            }
            items.put(new JSONObject().put("role",b.optString("role",i==0?"主单":"保险"))
                .put("pick",pick).put("state",st).put("needHome",needH).put("needAway",needA)
                .put("needed",needed).put("reachLevel",reachLevel).put("reachReason",reachReason));
        }
        output.put("items",items).put("hit",hit).put("pending",pending)
            .put("broken",broken).put("closed",closed)
            .put("nextHome",nextGoal(bets,h,a,"HOME"))
            .put("nextAway",nextGoal(bets,h,a,"AWAY"))
            .put("reachReason",reach.toString())
            .put("reachLevel",pending==0?"NONE":reachSupported?"ATTACK_SUPPORTED":reachTight?"TIME_TIGHT":
                validStats&&recent!=null?"UNCONFIRMED":"DATA_MISSING")
            .put("minimumGoalsNeeded",closest==99?-1:closest);
        if(hit+pending+broken==0){
            return output.put("level",closed>0?"CLOSED":"NONE")
                .put("title",closed>0?"已标记全部手动结算":"未填写有效比分")
                .put("reason",closed>0?"全部持仓已手动结算":"请先设置目标比分");
        }
        if(!MatchLifecycle.isLive(now.optString("status"),period))return output.put("level","OFF")
            .put("title","当前非有效比赛时段").put("reason","等待API确认对应半场/全场赛事状态");
        if(hit==0){
            if(pending==0)return output.put("level","BROKEN").put("action","核查剩余单据")
                .put("title","所有未结算比分单已失效")
                .put("reason","当前"+h+"-"+a+"已超出全部目标；不代表平台仍可提前结算");
            return output.put("level",broken>0?"PARTIAL":reachSupported?"REACH_WATCH":"PENDING")
                .put("title",reachSupported?"目标比分尚未到达 · 所需进球方出现攻势":
                    broken>0?"部分比分单失效 · 继续追踪可达目标":"目标比分尚未到达 · 评估可达条件")
                .put("reason",reach+"。"+timeContext(minute,period)+"；无法保证之后一定进球")
                .put("action",reachSupported?"关注目标比分是否到达":"继续观察");
        }
        StringBuilder matched=new StringBuilder();
        for(int i=0;i<items.length();i++){
            JSONObject item=items.optJSONObject(i);
            if(item!=null&&"HIT".equals(item.optString("state"))){
                if(matched.length()>0)matched.append("、");matched.append(item.optString("pick"));
            }
        }
        output.put("matched",matched.toString());
        JSONObject nextH=output.optJSONObject("nextHome"),nextA=output.optJSONObject("nextAway");
        String transition="下一球路径：主队再进→"+nextH.optString("score")+"（"+nextH.optString("summary")+
            "）；客队再进→"+nextA.optString("score")+"（"+nextA.optString("summary")+"）";
        output.put("transition",transition);
        boolean disrupted=now.optBoolean("newRed",false) ||
            (now.optLong("lastRedAt",0L)>0 && currentTime-now.optLong("lastRedAt",0L)<=3*60_000L);
        if(disrupted)return output.put("level","WATCH").put("action","核查平台实时结算报价")
            .put("title","比分"+matched+"已命中 · 红牌改变比赛结构")
            .put("reason",transition+"。刚出现红牌，无法据此前样本判断守分；"+timeContext(minute,period));
        if(!validStats)return output.put("level","UNKNOWN").put("action","核实实时数据")
            .put("title","比分"+matched+"命中 · 守分证据不足")
            .put("reason",transition+"。统计缺失或滞后，不推断安全；"+timeContext(minute,period));
        if(recent==null)return output.put("level","BASELINE").put("action","继续采样")
            .put("title","比分"+matched+"命中 · 重新观察守分")
            .put("reason",transition+"。缺少当前比分阶段的独立新样本；"+timeContext(minute,period));
        double ph=pressure(recent.optJSONObject("home")),pa=pressure(recent.optJSONObject("away"));
        if(!known(ph)||!known(pa))return output.put("level","UNKNOWN").put("action","继续采样")
            .put("title","比分"+matched+"命中 · 新数据不完整")
            .put("reason",transition+"。缺少射正、禁区射门等字段，不推断安全");
        JSONObject leading=ph>=pa?recent.optJSONObject("home"):recent.optJSONObject("away");
        String team=ph>=pa?"主队":"客队";
        double shots=val(leading,"shots"),on=val(leading,"on"),box=val(leading,"box"),xg=val(leading,"xg");
        boolean severe=(on>=2 && box>=2 && shots>=3) ||
            (known(xg)&&xg>=.35&&box>=1&&shots>=2);
        boolean warning=(on>=1&&box>=1&&shots>=2) ||
            (box>=2&&shots>=3) || (known(xg)&&xg>=.20&&shots>=2);
        String evidence="该比分阶段近"+recent.optInt("minutes",5)+"分钟"+team+"射门+"+fmt(shots)+
            "、射正+"+fmt(on)+"、禁区内+"+fmt(box)+"、xG+"+fmt(xg)+
            "；双方进攻信号"+fmt(ph+pa)+"（仅启发式指标，非概率）";
        output.put("evidence",evidence).put("sampleMinutes",recent.optInt("minutes",0));
        if(severe)return output.put("level","HIGH").put("action","立即核查平台结算报价")
            .put("title","比分"+matched+"命中 · 守分威胁显著")
            .put("reason",evidence+"。"+transition+"；"+timeContext(minute,period));
        if(warning)return output.put("level","WATCH").put("action","核查平台结算报价")
            .put("title","比分"+matched+"命中 · 出现新进攻威胁")
            .put("reason",evidence+"。"+transition+"；"+timeContext(minute,period));
        if(recent==now.optJSONObject("guardFast"))return output.put("level","BASELINE").put("action","继续观察")
            .put("title","比分"+matched+"命中 · 短窗尚待确认")
            .put("reason",evidence+"；样本不足3分钟，不能推断能守住");
        return output.put("level","LOW").put("action","继续观察")
            .put("title","比分"+matched+"命中 · 暂无高质量连续攻势")
            .put("reason",evidence+"。"+transition+"；"+timeContext(minute,period)+"。低风险信号不等于保证守住");
    }
}
