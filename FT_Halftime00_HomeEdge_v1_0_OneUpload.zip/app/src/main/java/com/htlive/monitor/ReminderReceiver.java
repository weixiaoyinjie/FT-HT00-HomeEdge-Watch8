package com.htlive.monitor;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.SystemClock;
import org.json.JSONArray;
import org.json.JSONObject;
import java.time.Instant;

/** Inexact OS alarms, resilient if the live polling UI is closed. Android Doze may delay delivery. */
public final class ReminderReceiver extends BroadcastReceiver {
    // -1 / 0 belong to the original screenshot path; 3 belongs only to
    // selector-checkbox monitoring. Shared milestones 15/30/40 are unchanged.
    private static final int[] MARKS={-1,0,3,15,30,40,60,75,85};
    private static final String PREF="ht_monitor",SAVE="alarm_watch";
    private static PendingIntent alarm(Context ctx,String id,int mark,int flags){
        Intent i=new Intent(ctx,ReminderReceiver.class);
        i.setAction("ht.reminder."+id+"."+mark);
        i.putExtra("id",id);i.putExtra("mark",mark);
        return PendingIntent.getBroadcast(ctx,(id+":"+mark).hashCode(),i,flags|PendingIntent.FLAG_IMMUTABLE);
    }
    public static void schedule(Context ctx,String json){
        SharedPreferences p=ctx.getSharedPreferences(PREF,Context.MODE_PRIVATE);
        AlarmManager am=(AlarmManager)ctx.getSystemService(Context.ALARM_SERVICE);
        try{
            JSONArray old=new JSONArray(p.getString(SAVE,"[]"));
            for(int i=0;i<old.length();i++){
                JSONObject o=old.optJSONObject(i);if(o==null)continue;
                String id=o.optString("id");if(!id.matches("[0-9]+"))continue;
                for(int mark:MARKS){PendingIntent pi=alarm(ctx,id,mark,PendingIntent.FLAG_NO_CREATE);if(pi!=null){am.cancel(pi);pi.cancel();}}
            }
            JSONArray requested=new JSONArray(json), saved=new JSONArray();
            long now=System.currentTimeMillis();
            for(int i=0;i<Math.min(requested.length(),12);i++){
                JSONObject item=requested.optJSONObject(i);if(item==null)continue;
                String id=item.optString("id"),iso=item.optString("kickoff");
                if(!id.matches("[0-9]+")||iso.isEmpty())continue;
                long kick;try{kick=Instant.parse(iso).toEpochMilli();}catch(Exception e){try{kick=java.time.OffsetDateTime.parse(iso).toInstant().toEpochMilli();}catch(Exception ignored){continue;}}
                saved.put(item);
                boolean viaSelector="selector".equals(item.optString("source")) ||
                    SelectorMonitorSync.isSelectedFixture(ctx,id);
                for(int mark:MARKS){
                    if(viaSelector && (mark==-1||mark==0))continue;
                    if(mark>=60 && !"FT".equals(item.optString("period",SelectorMonitorSync.period(ctx,id))))continue;
                    if(!viaSelector && mark==3)continue;
                    long at=mark==-1?kick-5*60_000L:kick+mark*60_000L;
                    // Very near the +3-minute boundary, never drop the only
                    // startup alarm merely because it is <3s away.
                    if(viaSelector && mark==3 && at>=now && at<now+3_000L)at=now+3_000L;
                    if(at<now+3000||at>now+50L*24*3600_000L)continue;
                    PendingIntent pi=alarm(ctx,id,mark,PendingIntent.FLAG_UPDATE_CURRENT);
                    if(mark==3){
                        try {
                            if(android.os.Build.VERSION.SDK_INT<31 || am.canScheduleExactAlarms())
                                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,pi);
                            else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,pi);
                        } catch(SecurityException permissionChanged){
                            // User can revoke exact-alarm access while this request is pending.
                            // Always keep a best-effort backup rather than losing the event.
                            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,pi);
                        }
                    }else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,pi);
                }
            }
            p.edit().putString(SAVE,saved.toString()).apply();
        }catch(Exception e){android.util.Log.e("HT","schedule failed",e);}
    }
    public static void cancelFinished(Context ctx,java.util.Set<String> ids){
        if(ids==null||ids.isEmpty())return;
        SharedPreferences p=ctx.getSharedPreferences(PREF,Context.MODE_PRIVATE);
        AlarmManager am=(AlarmManager)ctx.getSystemService(Context.ALARM_SERVICE);
        for(String id:ids){
            if(id==null||!id.matches("[0-9]+"))continue;
            for(int mark:MARKS){
                PendingIntent pi=alarm(ctx,id,mark,PendingIntent.FLAG_NO_CREATE);
                if(pi!=null){am.cancel(pi);pi.cancel();}
            }
        }
        // Keep other scheduled fixtures intact.
        try{
            JSONArray prior=new JSONArray(p.getString(SAVE,"[]")),left=new JSONArray();
            for(int n=0;n<prior.length();n++){
                JSONObject m=prior.optJSONObject(n);
                if(m!=null&&!ids.contains(m.optString("id")))left.put(m);
            }
            p.edit().putString(SAVE,left.toString()).apply();
        }catch(Exception ignored){}
    }
    @Override public void onReceive(Context ctx,Intent intent){
        if(intent==null)return;
        String id=intent.getStringExtra("id");int mark=intent.getIntExtra("mark",0);
        if(id==null||!id.matches("[0-9]+")||mark<-1||!(mark==-1 || mark==0 || mark==3 || mark==15 || mark==30 || mark==40 || mark==60 || mark==75 || mark==85))return;
        // An old kickoff alarm from a prior version must never bypass the new
        // three-minute gate when this fixture is currently selector-managed.
        if(mark==0 && SelectorMonitorSync.isSelectedFixture(ctx,id))return;
        if(mark==-1 || mark==3){
            SharedPreferences p=ctx.getSharedPreferences(PREF,Context.MODE_PRIVATE);
            String csv=p.getString("watchIds","");
            if(!p.getBoolean("autoArmFromImage",false))return;
            if(!java.util.Arrays.asList(csv.split(",")).contains(id)||p.getString("apiKey","").isEmpty())return;
            boolean selected=SelectorMonitorSync.isSelectedFixture(ctx,id);
            if(mark==3 && !selected)return;
            if(mark==-1 && selected)return;
            // A persisted running flag can be stale after Android process death.
            // The +3 start is idempotent; legacy screenshot behaviour is retained.
            if(mark==-1 && p.getBoolean("running",false))return;
            try{
                Intent i=new Intent(ctx,MonitorService.class).setAction("START");
                if(android.os.Build.VERSION.SDK_INT>=26)ctx.startForegroundService(i);
                else ctx.startService(i);
            }catch(Exception e){
                android.util.Log.w("HT","Android blocked alarm-driven monitoring",e);
                if(mark==3)AlertNotifier.post(ctx,"⚠ 第3分钟后台启动受限",id,null,System.currentTimeMillis(),
                    "系统拦截了后台预警服务，请立刻打开手机预警App核查；未确认比赛状态，不能视为已开始监控。");
            }
            return;
        }
        // Time checkpoints request fresh match data, but never tell a user to close
        // solely because 40' was reached. Risk alerts remain independently active.
        final PendingResult pending=goAsync();
        new Thread(()->{
            SharedPreferences p=ctx.getSharedPreferences(PREF,Context.MODE_PRIVATE);
            JSONObject match=null;long at=0;
            try{
                JSONObject snapshot=new JSONObject(p.getString("snapshot","{}"));
                JSONArray items=snapshot.optJSONArray("matches");
                if(items!=null)for(int i=0;i<items.length();i++){
                    JSONObject m=items.optJSONObject(i);
                    if(m!=null&&id.equals(m.optString("id"))){match=m;at=snapshot.optLong("updatedAt",0L);break;}
                }
                // Snapshot updatedAt can be refreshed by an API ERROR without
                // refreshing the fixture. Trust only its own successful timestamp.
                if(match!=null)at=match.optLong("fixtureSampledAt",0L);
                boolean ftNode=mark>=60 && SelectorMonitorSync.fullTime(ctx,id);
                boolean relevant=match!=null && (ftNode?
                    "2H".equals(match.optString("status")) && match.optInt("minute",-1)>=mark && match.optInt("minute",-1)<=mark+2 &&
                    at>0 && System.currentTimeMillis()-at<=60_000L:
                    mark==0?
                    AlertPolicy.kickoffFresh(System.currentTimeMillis(),at,
                        match.optString("status"),match.optInt("minute",-1)):
                    AlertPolicy.checkpointFresh(System.currentTimeMillis(),at,
                        match.optString("status"),match.optInt("minute",-1),mark));
                if(!relevant){
                    String key=p.getString("apiKey","");
                    if(!key.isEmpty())try{
                        JSONArray fixtures=ApiClient.get("fixtures?id="+id,key).optJSONArray("response");
                        if(fixtures!=null&&fixtures.length()>0){
                            JSONObject f=fixtures.optJSONObject(0);
                            JSONObject status=f.optJSONObject("fixture")==null?null:f.optJSONObject("fixture").optJSONObject("status");
                            if(status!=null && (ftNode?"2H":"1H").equals(status.optString("short")) &&
                                  status.optInt("elapsed",0)>=mark && status.optInt("elapsed",0)<=mark+2){
                                JSONObject teams=f.optJSONObject("teams");
                                int hid=teams.getJSONObject("home").optInt("id"),aid=teams.getJSONObject("away").optInt("id");
                                JSONObject stats=null;
                                try{
                                    stats=MatchData.combine(ApiClient.get("fixtures/statistics?fixture="+id+(ftNode?"":"&half=true"),key).optJSONArray("response"),hid,aid);
                                }catch(Exception e){
                                    // Valid fixture clock/score are still useful,
                                    // even when the optional stats API is down.
                                    android.util.Log.w("HT","checkpoint statistics unavailable",e);
                                }
                                JSONObject fresh=MatchData.parseFixture(f,stats);
                                fresh.put("period",ftNode?"FT":SelectorMonitorSync.period(ctx,id));
                                long sampled=System.currentTimeMillis();
                                fresh.put("fixtureSampledAt",sampled);
                                if(stats!=null)fresh.put("lastStatsAt",sampled);
                                // Keep previous trusted sampled history only when score/fixture match.
                                if(match!=null && match.optInt("h",-1)==fresh.optInt("h",-2) &&
                                   match.optInt("a",-1)==fresh.optInt("a",-2) && match.optJSONArray("history")!=null)
                                    fresh.put("history",match.optJSONArray("history"));
                                try{
                                    fresh.put("goalWarning",GoalWarningEngine.analyze(fresh,match,System.currentTimeMillis()));
                                    GoalWarningEngine.attachWindows(fresh,System.currentTimeMillis());
                                }catch(Exception e){
                                    // Detailed risk calculation is optional; never
                                    // make a valid clock/score reminder depend on it.
                                    android.util.Log.w("HT","checkpoint analysis unavailable",e);
                                }
                                match=fresh;at=sampled;
                            }else {relevant=false;match=null;}
                        }
                    }catch(Exception e){android.util.Log.w("HT","alarm data refresh failed",e);}
                }
                // Final check: even if the network response raced past the
                // milestone window, NEVER send a late stale checkpoint.
                relevant=match!=null && (ftNode?
                    "2H".equals(match.optString("status")) && match.optInt("minute",-1)>=mark && match.optInt("minute",-1)<=mark+2 &&
                    at>0 && System.currentTimeMillis()-at<=60_000L:
                    mark==0?
                    AlertPolicy.kickoffFresh(System.currentTimeMillis(),at,
                        match.optString("status"),match.optInt("minute",-1)):
                    AlertPolicy.checkpointFresh(System.currentTimeMillis(),at,
                        match.optString("status"),match.optInt("minute",-1),mark));
                if(relevant){
                    // Scheduled alarms sometimes outlive a running service. Reattach the
                    // current user-defined score portfolio so the reminder still describes
                    // actual tickets, not merely a generic score line.
                    try{
                        JSONObject byFixture=new JSONObject(p.getString("guardBets","{}"));
                        JSONArray bets=byFixture.optJSONArray(id);
                        if(bets!=null){
                            match.put("guardBets",bets);
                            match.put("guardRisk",ScoreGuardEngine.analyze(match,bets,System.currentTimeMillis()));
                        }
                    }catch(Exception e){android.util.Log.w("HT","checkpoint portfolio read failed",e);}
                    if(ftNode){
                        String delivered="delivered_"+id+"_"+mark;
                        if(!p.getBoolean(delivered,false) && p.edit().putBoolean(delivered,true).commit())
                            AlertNotifier.post(ctx,"⏱ 第"+mark+"分钟 · 全场比分路径复核",id,match,at,
                                "全场三张单；请核对最新攻守变化和平台手填结算价");
                    }else if(mark==0)AlertNotifier.postKickoff(ctx,id,match,at);
                    else AlertNotifier.postMark(ctx,id,mark,match,at);
                }else{
                    // Do not label a delayed or unstarted fixture as being in minute 0/15/30/40.
                    // The running foreground service will post the actual in-play milestone.
                    android.util.Log.i("HT","scheduled node not yet reached for fixture "+id+": "+mark);
                }
            }catch(Exception e){android.util.Log.w("HT","alarm node check failed",e);}
            finally{pending.finish();}
        },"HT-Node-Reminder").start();
    }
}
