package com.htlive.monitor;

/** Only for matches selected directly from the scanner. Legacy screenshot import is unchanged. */
final class SelectorStartPolicy {
    static final int START_MINUTE=3;
    private SelectorStartPolicy(){}
    static long startAt(long scheduledKickoffMs){
        return scheduledKickoffMs+START_MINUTE*60_000L;
    }
    static boolean startDue(long nowMs,long scheduledKickoffMs){
        return nowMs>=startAt(scheduledKickoffMs);
    }
    /** Never use scheduled wall time alone as proof that play has begun. */
    static boolean allowMatchAlerts(boolean isSelectorFixture,String status,int elapsed){
        return !isSelectorFixture || ("1H".equals(status) && elapsed>=START_MINUTE);
    }
}
