package com.htlive.monitor;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.net.Uri;
import android.widget.Toast;
import android.webkit.ValueCallback;
import org.json.JSONObject;
import org.json.JSONArray;
import com.google.mlkit.vision.text.Text;
import android.graphics.Rect;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import com.google.android.gms.tasks.Tasks;
import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Collections;
import android.util.Base64;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    public static final String EXTRA_FOCUS_FIXTURE="ht_focus_fixture";
    public static final String EXTRA_ALERT_FIXTURE="ht_alert_fixture";
    public static final String EXTRA_ALERT_TITLE="ht_alert_title";
    public static final String EXTRA_ALERT_DETAIL="ht_alert_detail";
    public static final String EXTRA_LIVE_RESULTS="ht_live_results";
    private WebView webView;
    private boolean pageReady=false;
    private Intent deferredOpenIntent;
    private ValueCallback<Uri[]> chooserCallback;
    private TextRecognizer recognizerLatin;
    private TextRecognizer recognizerChinese;
    private final ExecutorService network = Executors.newSingleThreadExecutor();
    // OCR is CPU-heavy; it must not block live API requests while processing long screenshots.
    private final ExecutorService ocrWorker = Executors.newSingleThreadExecutor();
    private static final int FILE_PICK=501;
    private final java.util.List<Uri> selectedScreenshotUris=new java.util.ArrayList<>();
    private SharedPreferences prefs;
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs=getSharedPreferences("ht_monitor",MODE_PRIVATE);
        deferredOpenIntent=getIntent();
        webView=new WebView(this);
        webView.setBackgroundColor(0xff07101d);
        setContentView(webView);
        WebSettings ws=webView.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setAllowFileAccess(true);
        ws.setAllowFileAccessFromFileURLs(false);
        ws.setAllowUniversalAccessFromFileURLs(false);
        ws.setDefaultTextEncodingName("utf-8");
        webView.setWebViewClient(new WebViewClient(){
            @Override public void onPageFinished(WebView view,String url){
                pageReady=true;
                dispatchDeferredOpen();
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, android.webkit.WebResourceRequest req) {
                return !"file".equalsIgnoreCase(req.getUrl().getScheme());
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (chooserCallback!=null) chooserCallback.onReceiveValue(null);
                chooserCallback=callback;
                try {
                    Intent intent=new Intent(Intent.ACTION_GET_CONTENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("image/*");
                    intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);
                    startActivityForResult(Intent.createChooser(intent,"选择下注截图"),FILE_PICK);
                    return true;
                } catch(Exception e){ chooserCallback=null; return false; }
            }
        });
        webView.addJavascriptInterface(new Bridge(),"NativeHT");
        recognizerLatin=TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
        recognizerChinese=TextRecognition.getClient(new ChineseTextRecognizerOptions.Builder().build());
        webView.loadUrl("file:///android_asset/index.html");
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},102);
        }
    }
    @Override protected void onNewIntent(Intent incoming){
        super.onNewIntent(incoming);
        setIntent(incoming);
        deferredOpenIntent=incoming;
        dispatchDeferredOpen();
    }
    private void dispatchDeferredOpen(){
        if(!pageReady||webView==null||deferredOpenIntent==null)return;
        Intent incoming=deferredOpenIntent;
        String alertId=incoming.getStringExtra(EXTRA_ALERT_FIXTURE);
        String focusId=incoming.getStringExtra(EXTRA_FOCUS_FIXTURE);
        if(alertId!=null&&alertId.matches("[0-9]{1,12}")){
            String title=incoming.getStringExtra(EXTRA_ALERT_TITLE);
            String detail=incoming.getStringExtra(EXTRA_ALERT_DETAIL);
            String js="window.showNativeAlert&&window.showNativeAlert("+
                JSONObject.quote(alertId)+","+JSONObject.quote(title==null?"":title)+","+
                JSONObject.quote(detail==null?"":detail)+");";
            deferredOpenIntent=null;
            webView.post(()->webView.evaluateJavascript(js,null));
        }else if(focusId!=null&&focusId.matches("[0-9]{1,12}")){
            deferredOpenIntent=null;
            webView.post(()->webView.evaluateJavascript("window.focusSelectorFixture&&window.focusSelectorFixture("+
                JSONObject.quote(focusId)+");",null));
        }else if(incoming.getBooleanExtra(EXTRA_LIVE_RESULTS,false)){
            deferredOpenIntent=null;
            webView.post(()->webView.evaluateJavascript(
                "window.focusLiveResults&&window.focusLiveResults();",null));
        }else deferredOpenIntent=null;
    }
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==FILE_PICK && chooserCallback!=null){
            Uri[] uris=null;
            if(resultCode==RESULT_OK && data!=null) {
                if(data.getClipData()!=null){
                    int size=Math.min(12,data.getClipData().getItemCount());
                    uris=new Uri[size];
                    for(int i=0;i<size;i++) uris[i]=data.getClipData().getItemAt(i).getUri();
                } else if(data.getData()!=null) uris=new Uri[]{data.getData()};
            }
            synchronized(selectedScreenshotUris){
                selectedScreenshotUris.clear();
                if(uris!=null)java.util.Collections.addAll(selectedScreenshotUris,uris);
            }
            chooserCallback.onReceiveValue(uris); chooserCallback=null;
        }
    }
    /**
     * Screenshot timetable OCR: keep only mint/green kickoff headings or white
     * fixture rows. Yellow reminder timestamps must NEVER become kickoff times.
     * Colors are read from the original pixels, not OCR's guessed strings.
     */
    private static Bitmap colorMask(Bitmap original, boolean mint) {
        int width=original.getWidth(), height=original.getHeight();
        int[] source=new int[width*height], masked=new int[source.length];
        original.getPixels(source,0,width,0,0,width,height);
        int count=0;
        for(int i=0;i<source.length;i++){
            int c=source[i],r=Color.red(c),g=Color.green(c),b=Color.blue(c);
            // Screenshot mint: e.g. RGB(155,240,220). White: (227,237,249).
            // Yellow (245,209,153) fails BOTH tests.
            boolean green=g>=125 && g-r>=25 && g-b>=4 && b>=r+9;
            // Key fix for ID-card screenshots: labels are truly pure white
            // (#FFFFFF), not necessarily blue-tinted white.
            boolean white=r>=165 && g>=165 && b>=165
                    && Math.abs(r-g)<=25 && Math.abs(g-b)<=25
                    && Math.abs(r-b)<=25 && r+g+b>=540 && !green;
            boolean accept=mint?green:white;
            masked[i]=accept?Color.BLACK:Color.WHITE;
            if(accept)count++;
        }
        Bitmap out=Bitmap.createBitmap(width,height,Bitmap.Config.ARGB_8888);
        out.setPixels(masked,0,width,0,0,width,height);
        return out;
    }
    private static void extractOcrLines(Text text, JSONArray output,String source,String color,int yOffset){
        if(text==null)return;
        try {
            for(Text.TextBlock block:text.getTextBlocks())for(Text.Line line:block.getLines()){
                Rect r=line.getBoundingBox();if(r==null||line.getText().trim().isEmpty())continue;
                output.put(new JSONObject().put("t",line.getText()).put("x",r.left).put("y",r.top+yOffset)
                    .put("w",r.width()).put("h",r.height()).put("source",source).put("color",color));
            }
        }catch(Exception ignored){}
    }
    private static boolean isFallbackMatchLine(String raw){
        String t=raw==null?"":raw.trim();
        // Do not turn yellow reminder times into green kickoff headings.
        return java.util.regex.Pattern.compile("(?i)fixture\\s*(?:i[d0]|1d|ld)?|\\bvs?\\.?\\b|\\b[0-9]{5,10}\\b")
                .matcher(t).find();
    }
    private static void addFullImageFallback(Text raw,JSONArray output,int yOffset){
        if(raw==null)return;
        try{
            for(Text.TextBlock block:raw.getTextBlocks())for(Text.Line line:block.getLines()){
                Rect r=line.getBoundingBox();if(r==null||!isFallbackMatchLine(line.getText()))continue;
                String t=line.getText().trim();
                boolean exists=false;
                for(int i=0;i<output.length();i++){
                    JSONObject old=output.optJSONObject(i);if(old==null)continue;
                    if(Math.abs(old.optInt("y")-(r.top+yOffset))<=Math.max(9,r.height()/2)
                        && Math.abs(old.optInt("x")-r.left)<=65){
                        String prev=old.optString("t");
                        boolean sameTeam=prev.toLowerCase(java.util.Locale.ROOT).contains("vs")
                                && t.toLowerCase(java.util.Locale.ROOT).contains("vs");
                        boolean sameId=prev.toLowerCase(java.util.Locale.ROOT).contains("fixture")
                                && t.toLowerCase(java.util.Locale.ROOT).contains("fixture");
                        if(sameTeam||sameId){
                            // Replace weaker masked OCR rather than concatenating two
                            // slightly different team labels on the same visual row.
                            if(t.length()>prev.length()+2){
                                output.put(i,new JSONObject().put("t",t).put("x",r.left)
                                    .put("y",r.top+yOffset).put("w",r.width()).put("h",r.height())
                                    .put("source","original").put("color","white"));
                            }
                            exists=true;break;
                        }
                    }
                }
                if(!exists)output.put(new JSONObject().put("t",t).put("x",r.left)
                    .put("y",r.top+yOffset).put("w",r.width()).put("h",r.height())
                    .put("source","original").put("color","white"));
            }
        }catch(Exception ignored){}
    }
    private static JSONArray sortAndDeduplicate(JSONArray lines){
        ArrayList<JSONObject> entries=new ArrayList<>();
        for(int i=0;i<lines.length();i++)if(lines.optJSONObject(i)!=null)entries.add(lines.optJSONObject(i));
        Collections.sort(entries,(a,b)->{
            int y=Integer.compare(a.optInt("y"),b.optInt("y"));
            return y!=0?y:Integer.compare(a.optInt("x"),b.optInt("x"));
        });
        JSONArray result=new JSONArray();
        for(JSONObject line:entries){
            boolean duplicate=false;
            String normalized=line.optString("t").replaceAll("[^\\p{L}\\p{N}]", "").toLowerCase(java.util.Locale.ROOT);
            for(int i=Math.max(0,result.length()-9);i<result.length();i++){
                JSONObject old=result.optJSONObject(i);if(old==null)continue;
                if(Math.abs(old.optInt("y")-line.optInt("y"))<14
                  && Math.abs(old.optInt("x")-line.optInt("x"))<55
                  && normalized.equals(old.optString("t").replaceAll("[^\\p{L}\\p{N}]", "").toLowerCase(java.util.Locale.ROOT))){
                    duplicate=true;break;
                }
            }
            if(!duplicate)result.put(line);
        }
        return result;
    }
    private void sendOcrResult(String photoId,JSONArray rawLines,String priorError){
        JSONArray lines=sortAndDeduplicate(rawLines);
        StringBuilder b=new StringBuilder();
        for(int i=0;i<lines.length();i++){
            JSONObject line=lines.optJSONObject(i);
            if(line!=null){if(b.length()>0)b.append('\n');b.append(line.optString("t"));}
        }
        String error=b.length()>0?"":priorError;
        js("window.nativeOcrDone("+JSONObject.quote(photoId)+","+JSONObject.quote(b.toString())+","+JSONObject.quote(error)+","+JSONObject.quote(lines.toString())+")");
    }
    private File ocrOriginalFile(String id){
        if(id==null||!id.matches("[a-zA-Z0-9_-]{1,80}"))throw new IllegalArgumentException("无效截图ID");
        return new File(getFilesDir(),"scorepath_ocr_"+id+".jpg");
    }
    private void processOcr(String photoId, String base64Data, boolean reload){
        Bitmap bitmap=null;
        try{
            byte[] image;
            if(reload){
                File saved=ocrOriginalFile(photoId);
                if(!saved.isFile()){sendOcrResult(photoId,new JSONArray(),"找不到原始截图，请重新上传图片");return;}
                image=java.nio.file.Files.readAllBytes(saved.toPath());
            }else{
                if(base64Data==null||base64Data.length()>30_000_000)throw new Exception("截图太大，请裁剪或分批上传");
                int comma=base64Data.indexOf(',');if(comma<0)throw new Exception("无效图片格式");
                image=Base64.decode(base64Data.substring(comma+1),Base64.DEFAULT);
                if(image.length>22_000_000)throw new Exception("截图太大，请裁剪或分批上传");
            }
            BitmapFactory.Options opts=new BitmapFactory.Options();opts.inJustDecodeBounds=true;
            BitmapFactory.decodeByteArray(image,0,image.length,opts);
            if(opts.outWidth<=0||opts.outHeight<=0||((long)opts.outWidth*opts.outHeight)>36_000_000L)
                throw new Exception("截图分辨率过大，请拆成两张再上传");
            bitmap=BitmapFactory.decodeByteArray(image,0,image.length);
            if(bitmap==null)throw new Exception("无法解析截图");
            if(!reload){try(FileOutputStream f=new FileOutputStream(ocrOriginalFile(photoId))){f.write(image);}}
            JSONArray lines=new JSONArray();
            int step=1330, overlap=100;
            // Keep original pixels for every row: no whole-image downscale of long match lists.
            for(int y=0;y<bitmap.getHeight();y+=step){
                int top=Math.max(0,y-(y==0?0:overlap));
                int h=Math.min(1530,bitmap.getHeight()-top);
                Bitmap section=null,heading=null,teams=null;
                try{
                    section=Bitmap.createBitmap(bitmap,0,top,bitmap.getWidth(),h);
                    heading=colorMask(section,true);teams=colorMask(section,false);
                    try{extractOcrLines(Tasks.await(recognizerChinese.process(InputImage.fromBitmap(heading,0))),lines,"chinese","green",top);}
                    catch(Exception ignored){}
                    try{extractOcrLines(Tasks.await(recognizerLatin.process(InputImage.fromBitmap(teams,0))),lines,"latin","white",top);}
                    catch(Exception ignored){}
                    // Always use the unmasked pass, even if the FIRST match's ID was
                    // found; otherwise later cards with weak glyphs are lost.
                    try{addFullImageFallback(Tasks.await(recognizerLatin.process(InputImage.fromBitmap(section,0))),lines,top);}
                    catch(Exception ignored){}
                }finally{
                    if(heading!=null&&!heading.isRecycled())heading.recycle();
                    if(teams!=null&&!teams.isRecycled())teams.recycle();
                    if(section!=null&&section!=bitmap&&!section.isRecycled())section.recycle();
                }
                if(top+h>=bitmap.getHeight())break;
            }
            sendOcrResult(photoId,lines,lines.length()==0?"没有读到比赛信息，请使用清晰截图或编辑识别文字":"");
        }catch(Exception e){sendOcrResult(photoId,new JSONArray(),"截图识别失败："+e.getMessage());}
        finally{if(bitmap!=null&&!bitmap.isRecycled())bitmap.recycle();}
    }
    @Override protected void onResume(){
        super.onResume();
        if(webView!=null)webView.post(()->webView.evaluateJavascript(
            "window.refreshSelectorSelections&&window.refreshSelectorSelections();",null));
    }
    private void js(String expression){runOnUiThread(()->webView.evaluateJavascript(expression,null));}
    public class Bridge {
        @JavascriptInterface public void openSelector(){
            runOnUiThread(()->{
                Intent intent=new Intent(MainActivity.this,SelectorActivity.class);
                // Reuse the same selector screen so scan results survive page switches.
                intent.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                startActivity(intent);
            });
        }
        @JavascriptInterface public String getSelectorMatches(){
            return SelectorMonitorSync.selectorMatches(MainActivity.this);
        }
        @JavascriptInterface public String getKey(){return prefs.getString("apiKey","");}
        @JavascriptInterface public String getAiKey(){return prefs.getString("openaiKey","");}
        @JavascriptInterface public void saveAiKey(String key){prefs.edit().putString("openaiKey",key==null?"":key.trim()).apply();}
        @JavascriptInterface public void saveKey(String key){prefs.edit().putString("apiKey",key.trim()).apply();}
        @JavascriptInterface public String state(){
            JSONObject result=new JSONObject();
            try {
                result.put("running",prefs.getBoolean("running",false));
                result.put("snapshot",new JSONObject(prefs.getString("snapshot","{}")));
                result.put("alerts",new org.json.JSONArray(prefs.getString("alerts","[]")));
                result.put("checkpoints",new JSONArray(prefs.getString("checkpoints","[]")));
                result.put("ids",prefs.getString("watchIds",""));
                result.put("interval",prefs.getInt("interval",60));
                result.put("autoPruned",new JSONArray(prefs.getString("autoPruned","[]")));
                result.put("mainPicks",new JSONObject(prefs.getString("mainPicks","{}")));
                result.put("guardBets",new JSONObject(prefs.getString("guardBets","{}")));
                result.put("guardJournal",new JSONArray(prefs.getString("guardJournal","[]")));
            }catch(Exception ignored){}
            return result.toString();
        }
        /** One optional exact-score target per fixture. Stored locally, never in a public ZIP. */
        @JavascriptInterface public String saveMainPick(String fixtureId,String score){
            if(fixtureId==null || !fixtureId.matches("[0-9]{1,12}"))return "比赛ID无效";
            String pick=score==null?"":score.trim().replace('：','-').replace(':','-');
            if(!pick.isEmpty() && !MainScoreRiskEngine.validPick(pick))return "请输入 1-0、0-0、0-1 等主:客比分（0–9）";
            synchronized(MainActivity.this){
                try{
                    JSONObject picks=new JSONObject(prefs.getString("mainPicks","{}"));
                    if(pick.isEmpty())picks.remove(fixtureId);else picks.put(fixtureId,pick);
                    if(!prefs.edit().putString("mainPicks",picks.toString()).commit())return "保存失败，请重试";
                }catch(Exception ex){return "保存失败："+ex.getMessage();}
            }
            return "OK";
        }
        /** All cashout values are entered by the user; never scrape bookmaker accounts. */
        @JavascriptInterface public String saveGuardBets(String fixtureId,String json){
            if(fixtureId==null||!fixtureId.matches("[0-9]{1,12}"))return "无效比赛ID";
            try{
                JSONArray rows=new JSONArray(json);
                if(rows.length()>3)return "最多一张主单两张保险单";
                if(SelectorMonitorSync.isSelectedFixture(MainActivity.this,fixtureId)){
                    int need=SelectorMonitorSync.fullTime(MainActivity.this,fixtureId)?3:2;
                    if(rows.length()!=need)return "此场筛选已锁定"+(need==3?"全场3张":"半场2张")+"，请按对应数量保存";
                }
                JSONArray verified=new JSONArray();String main="";
                for(int i=0;i<rows.length();i++){
                    JSONObject b=rows.optJSONObject(i);if(b==null)return "无效的比分单";
                    String score=b.optString("pick","").trim().replace(':','-').replace('：','-');
                    if(!score.isEmpty()&&!ScoreGuardEngine.validPick(score))return "比分必须为1-0、0-0、0-1等格式";
                    double stake=b.optDouble("stake",0),offer=b.optDouble("offer",0);
                    if(!Double.isFinite(stake)||!Double.isFinite(offer)||stake<0||offer<0||stake>1000000000||offer>1000000000)
                        return "金额必须为非负数且不超过十亿";
                    if(i==0)main=score;
                    verified.put(new JSONObject().put("role",i==0?"主单":"保险"+i)
                        .put("pick",score).put("stake",stake).put("offer",offer)
                        .put("closed",b.optBoolean("closed",false)));
                }
                synchronized(MainActivity.this){
                    JSONObject all=new JSONObject(prefs.getString("guardBets","{}"));
                    JSONObject mains=new JSONObject(prefs.getString("mainPicks","{}"));
                    all.put(fixtureId,verified);
                    if(main.isEmpty())mains.remove(fixtureId);else mains.put(fixtureId,main);
                    if(!prefs.edit().putString("guardBets",all.toString())
                        .putString("mainPicks",mains.toString()).commit())return "存储失败，请重试";
                }
                GuardJournal.noteManual(MainActivity.this,fixtureId,verified);
                return "OK";
            }catch(Exception e){return "格式错误："+e.getMessage();}
        }
        @JavascriptInterface public String acknowledgeGuard(String fixtureId){
            if(fixtureId==null||!fixtureId.matches("[0-9]{1,12}"))return "无效比赛ID";
            android.content.Intent done=new android.content.Intent(MainActivity.this,GuardActionReceiver.class);
            done.setAction("GUARD_ACK").putExtra("id",fixtureId);
            new GuardActionReceiver().onReceive(MainActivity.this,done);
            return "OK";
        }
        @JavascriptInterface public void request(String rid,String path,String key){
            network.execute(()->{
                String raw;
                try { raw=ApiClient.get(path,key).toString(); }
                catch(Exception e){ try {JSONObject err=new JSONObject();err.put("_error",e.getMessage());raw=err.toString();}catch(Exception x){raw="{\"_error\":\"请求失败\"}";} }
                js("window.nativeDone("+JSONObject.quote(rid)+","+JSONObject.quote(raw)+")");
            });
        }
        @JavascriptInterface public void setInterval(int seconds){
            prefs.edit().putInt("interval",Math.max(30,Math.min(300,seconds))).apply();
        }
        @JavascriptInterface public void start(String csv,int interval){
            String key=prefs.getString("apiKey","");
            if(key.isEmpty()) { js("window.nativeToast('请先保存API Key')"); return; }
            if(csv==null || !csv.matches("[0-9]+(,[0-9]+){0,11}")){js("window.nativeToast('请先选择1至12场比赛')");return;}
            int seconds=Math.max(30,Math.min(300,interval));
            prefs.edit().putString("watchIds",csv).putInt("interval",seconds).apply();
            Intent intent=new Intent(MainActivity.this,MonitorService.class).setAction("START");
            try { androidxFallbackStart(intent); js("window.nativeToast('监控已启动')"); }
            catch(Exception e){js("window.nativeToast("+JSONObject.quote("启动失败："+e.getMessage())+")");}
        }
        @JavascriptInterface public String updateWatchlist(String csv){
            if(csv==null) return "比赛名单无效";
            if(!csv.isEmpty() && !csv.matches("[0-9]+(,[0-9]+){0,11}")) return "最多只能监控12场有效比赛";
            prefs.edit().putString("watchIds",csv).apply();
            SelectorMonitorSync.pruneToWatchlist(MainActivity.this,csv);
            if(csv.isEmpty()){
                prefs.edit().putBoolean("autoArmFromImage",false).apply();
                Intent intent=new Intent(MainActivity.this,MonitorService.class).setAction("STOP");
                startService(intent);
            }
            // The foreground worker reads watchIds on its next polling cycle.
            // New fixtures establish a baseline before generating event alerts.
            return "OK";
        }
        /** Called only after screenshot IDs have been verified against API-FOOTBALL.
         * Queue the fixture reminders and arm automatic live polling near kickoff.
         */
        @JavascriptInterface public String armImportedMatches(String csv,String matchesJson,int requestedInterval){
            if(csv==null||!csv.matches("[0-9]+(,[0-9]+){0,11}"))return "ERROR:监控比赛ID不合法";
            if(prefs.getString("apiKey","").trim().isEmpty())return "ERROR:请先保存API Key";
            try {
                JSONArray matches=new JSONArray(matchesJson);
                if(matches.length()==0)return "ERROR:观察名单为空";
                boolean imminent=false,scheduled=false;
                long now=System.currentTimeMillis();
                for(int k=0;k<matches.length();k++){
                    JSONObject m=matches.optJSONObject(k);if(m==null)continue;
                    long kickoff;
                    try { kickoff=java.time.OffsetDateTime.parse(m.optString("kickoff")).toInstant().toEpochMilli(); }
                    catch(Exception ex){continue;}
                    // Starts at most ten minutes before kickoff; don't consume 6-hour
                    // Android 15 data-sync service budget on a next-day fixture.
                    if(kickoff>=now-55L*60_000L && kickoff<=now+10L*60_000L)imminent=true;
                    if(kickoff>now+10L*60_000L)scheduled=true;
                }
                prefs.edit().putString("watchIds",csv)
                    .putBoolean("autoArmFromImage",true)
                    .putInt("interval",Math.max(30,Math.min(300,requestedInterval))).apply();
                ReminderReceiver.schedule(MainActivity.this,matchesJson);
                if(imminent){
                    // Explicitly call onStartCommand even if an old 'running' flag
                    // survived process death. The service itself is idempotent.
                    androidxFallbackStart(new Intent(MainActivity.this,MonitorService.class).setAction("START"));
                    return "STARTED";
                }
                return scheduled?"ARMED":"ERROR:比赛已超过上半场观察窗口";
            }catch(Exception e){return "ERROR:"+e.getMessage();}
        }
        @JavascriptInterface public void stop(){
            prefs.edit().putBoolean("autoArmFromImage",false).apply();
            Intent intent=new Intent(MainActivity.this,MonitorService.class).setAction("STOP");
            startService(intent);
            js("window.nativeToast('监控已停止')");
        }
        @JavascriptInterface public void notifyTest(){
            try {
                JSONObject x=new JSONObject().put("id","0").put("home","演示主队").put("away","演示客队")
                  .put("status","1H").put("minute",25).put("h",0).put("a",0).put("trend","主队近5分钟压制");
                JSONObject h=new JSONObject().put("xg",0.65).put("shots",5).put("on",2).put("box",3).put("pos",58);
                JSONObject a=new JSONObject().put("xg",0.18).put("shots",2).put("on",1).put("box",1).put("pos",42);
                x.put("stats",new JSONObject().put("available",true).put("home",h).put("away",a));
                x.put("goalWarning",new JSONObject().put("level","strong").put("rating","B级")
                    .put("title","演示主队持续施压 · 可能出现进球机会")
                    .put("reason","演示数据：最近5分钟射门+4、射正+2、禁区射门+3，非真实比赛")
                    .put("momentum","演示：近10分钟持续占优")
                    .put("risk","这是通知样式测试，不是赛事判断"));
                AlertNotifier.post(MainActivity.this,"模拟进球预警（演示数据，不是真实比赛）","0",x,System.currentTimeMillis(),"");
            } catch(Exception e){js("window.nativeToast("+JSONObject.quote("通知测试失败："+e.getMessage())+")");}
        }
        @JavascriptInterface public void scheduleReminders(String matchesJson){
            try {ReminderReceiver.schedule(MainActivity.this,matchesJson);}
            catch(Exception e){js("window.nativeToast("+JSONObject.quote("安排节点提醒失败："+e.getMessage())+")");}
        }
        /** Use the actual user-selected screenshot directly. The web page stores only a small thumbnail. */
        @JavascriptInterface public void ocrSelectedFile(String photoId,int selectionIndex){
            final Uri uri;
            synchronized(selectedScreenshotUris){
                uri=selectionIndex>=0 && selectionIndex<selectedScreenshotUris.size()
                    ? selectedScreenshotUris.get(selectionIndex):null;
            }
            if(uri==null){
                js("window.nativeOcrDone("+JSONObject.quote(photoId)+",'',"+
                    JSONObject.quote("图片来源已变化，请重新选择截图")+",'[]')");
                return;
            }
            ocrWorker.execute(()->{
                try(java.io.InputStream in=getContentResolver().openInputStream(uri);
                    java.io.ByteArrayOutputStream out=new java.io.ByteArrayOutputStream()){
                    if(in==null)throw new Exception("无法读取所选图片");
                    byte[] buf=new byte[32_768];int n,total=0;
                    while((n=in.read(buf))!=-1){
                        total+=n;if(total>22_000_000)throw new Exception("原图超过22MB，请裁剪后上传");
                        out.write(buf,0,n);
                    }
                    byte[] bytes=out.toByteArray();
                    if(bytes.length==0)throw new Exception("截图内容为空");
                    // Legacy OCR worker already tiles full-resolution images; reuse its saved-file path.
                    try(FileOutputStream dest=new FileOutputStream(ocrOriginalFile(photoId))){dest.write(bytes);}
                    processOcr(photoId,null,true);
                }catch(Exception ex){sendOcrResult(photoId,new JSONArray(),"原图识别失败："+ex.getMessage());}
            });
        }
        @JavascriptInterface public void ocr(String photoId,String base64Data){
            ocrWorker.execute(()->processOcr(photoId,base64Data,false));
        }
        @JavascriptInterface public void reocr(String photoId,String previewFallback){
            ocrWorker.execute(()->{
                boolean exists=false;
                try{exists=ocrOriginalFile(photoId).isFile();}catch(Exception ignored){}
                processOcr(photoId,exists?null:previewFallback,exists);
            });
        }
        @JavascriptInterface public void deleteOcrOriginal(String photoId){
            ocrWorker.execute(()->{try{ocrOriginalFile(photoId).delete();}catch(Exception ignored){}});
        }
        @JavascriptInterface public void requestNotification(){
            if(Build.VERSION.SDK_INT>=33){runOnUiThread(()->{if(checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},102);});}
        }
    }
    private void androidxFallbackStart(Intent i){
        if(Build.VERSION.SDK_INT>=26) startForegroundService(i); else startService(i);
    }
    @Override public void onBackPressed(){ if(webView!=null && webView.canGoBack())webView.goBack();else super.onBackPressed(); }
    @Override protected void onDestroy(){
        if(chooserCallback!=null){chooserCallback.onReceiveValue(null);chooserCallback=null;}
        network.shutdownNow();
        ocrWorker.shutdownNow();
        if(recognizerLatin!=null)recognizerLatin.close();
        if(recognizerChinese!=null)recognizerChinese.close();
        if(webView!=null){webView.removeJavascriptInterface("NativeHT");webView.destroy();}
        super.onDestroy();
    }
}
